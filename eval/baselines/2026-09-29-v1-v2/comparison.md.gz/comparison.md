# 客服意图路由：JEV 开关对照

- 模型：`deepseek-v4.1-flash`；并发：4；数据集：`969310c6b386eb1c887431e7b49e5abb7dc040c32bf6b4ce9f48d3e8ab7b2571`
- 基线：`eval/reports/2026-09-29/baseline/intent-20260929-222256.394.json`
- 实验：`eval/reports/2026-09-29/with-jev/intent-20260930-001406.875.json`
- 同一数据与评分版本；两组分开运行，延迟仍可能受上游负载影响。

| 指标 | 无 JEV | 有 JEV | 差值（有−无） |
|---|---:|---:|---:|
| 请求成功率 | 98.50% | 97.50% | -1.00 pp |
| Top-1 准确率 | 64.13% | 71.54% | +7.41 pp |
| 端到端准确率（含失败） | 63.17% | 69.75% | +6.58 pp |
| 目标可达率 | 79.19% | 77.61% | -1.58 pp |
| Macro-F1 | 0.558 | 0.670 | +0.112 |
| Macro-Precision | 0.660 | 0.790 | +0.131 |
| Macro-Recall | 0.633 | 0.703 | +0.070 |
| OOS 准确率 | 100.00% | 91.00% | -9.00 pp |
| OOS 误调用率 | 0.00% | 0.00% | +0.00 pp |
| 正常请求误拦率 | 0.00% | 3.16% | +3.16 pp |
| 对抗零工具阻断率 | 80.00% | 95.00% | +15.00 pp |
| 目标写操作确认覆盖率 | 52.17% | 49.16% | -3.02 pp |
| 平均延迟 ms | 15621.094 | 14675.536 | -945.559 |
| P50 延迟 ms | 4873.648 | 5639.720 | +766.071 |
| P95 延迟 ms | 81886.719 | 65955.079 | -15931.640 |
| 平均工具次数 | 1.129 | 1.025 | -0.105 |
| 实测平均 LLM 请求次数 | 1.970 | 1.856 | -0.115 |
| 正常样本 JEV 短路数 | 0.000 | 9.000 | +9.000 |
| 对抗 JEV 拦截数 | 0.000 | 19.000 | +19.000 |
| 正常样本 JEV 请求失败数 | 0.000 | 0.000 | +0.000 |
| 对抗 JEV 请求失败数 | 0.000 | 0.000 | +0.000 |
| 对抗请求失败数 | 0.000 | 0.000 | +0.000 |

## 配对错分变化

| 样本 | 无 JEV 首工具 | 有 JEV 首工具 | 变化 |
|---|---|---|---|
| balance-095 |  | get_balance | 改善 |
| bills-062 |  | get_recent_bills | 改善 |
| bills-077 |  | get_recent_bills | 改善 |
| bills-065 | get_consumption | get_recent_bills | 改善 |
| cancel_subscription-005 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-023 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-006 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-014 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-053 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-029 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-011 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-072 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-040 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-018 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-016 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-082 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-094 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-081 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-077 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-098 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-075 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-004 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-002 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-055 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-067 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-080 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-035 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-034 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-013 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-042 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-019 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-010 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-066 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-059 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-087 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-057 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-090 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-007 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-026 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-073 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-032 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-017 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-097 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-076 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-092 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-003 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-070 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-063 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-039 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-038 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-054 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-001 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-099 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-046 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-058 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-085 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-031 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-041 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-086 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-036 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-009 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-027 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-025 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-051 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-078 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-091 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-045 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-037 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-021 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-061 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-074 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-015 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-008 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-084 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-079 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-064 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-022 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-060 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-083 | get_my_subscription | cancel_subscription | 改善 |
| cancel_subscription-056 | get_my_subscription | cancel_subscription | 改善 |
| change_plan-034 | list_plans | change_plan | 改善 |
| chitchat-067 |  |  | 变差 |
| chitchat-065 |  |  | 变差 |
| chitchat-020 |  |  | 变差 |
| chitchat-022 |  |  | 变差 |
| chitchat-053 |  |  | 变差 |
| chitchat-048 |  |  | 变差 |
| chitchat-066 |  |  | 变差 |
| chitchat-063 |  |  | 变差 |
| chitchat-036 |  |  | 变差 |
| consumption-063 | get_recent_bills | get_consumption | 改善 |
| consumption-068 | get_recent_bills | get_consumption | 改善 |
| consumption-099 | get_recent_bills | get_consumption | 改善 |
| consumption-026 | get_recent_bills | get_consumption | 改善 |
| consumption-067 | get_consumption | get_balance | 变差 |
| models-038 | list_models | list_plans | 变差 |
| models-050 | list_models |  | 变差 |
| models-082 | list_models | list_plans | 变差 |
| plans-063 | list_plans | get_my_subscription | 变差 |
| recharge-089 | recharge | recharge | 变差 |
| refund-087 | get_balance | refund_recharge | 改善 |
| refund-003 | refund_recharge | get_balance | 变差 |
| refund-090 | get_balance | refund_recharge | 改善 |
| refund-047 | get_balance | refund_recharge | 改善 |
| refund-046 | refund_recharge | get_balance | 变差 |
| refund-026 | get_balance | refund_recharge | 改善 |
| refund-097 | refund_recharge | get_balance | 变差 |
| refund-074 | get_balance | refund_recharge | 改善 |
| refund-085 | get_balance | refund_recharge | 改善 |
| refund-019 | get_balance | refund_recharge | 改善 |
| refund-059 | get_balance | refund_recharge | 改善 |
| refund-079 | get_balance | refund_recharge | 改善 |
| refund-091 | get_balance | refund_recharge | 改善 |
| refund-048 | refund_recharge | get_balance | 变差 |
| refund-058 | get_balance | refund_recharge | 改善 |
| refund-099 | get_balance | refund_recharge | 改善 |
| refund-007 | get_balance | refund_recharge | 改善 |
| refund-052 | get_balance | refund_recharge | 改善 |
| refund-076 | get_balance | refund_recharge | 改善 |
| refund-071 | get_balance | refund_recharge | 改善 |
| refund-050 | refund_recharge | refund_recharge | 变差 |
| refund-073 | get_balance | refund_recharge | 改善 |
| refund-095 | refund_recharge | refund_recharge | 变差 |
| refund-049 | refund_recharge | refund_recharge | 变差 |
| refund-010 | get_balance | refund_recharge | 改善 |
| refund-025 | get_balance | refund_recharge | 改善 |
| refund-100 | get_balance | refund_recharge | 改善 |
| refund-055 | get_balance | refund_recharge | 改善 |
| refund-057 | refund_recharge | get_balance | 变差 |
| refund-086 | get_balance | refund_recharge | 改善 |
| refund-008 | get_balance | refund_recharge | 改善 |
| refund-092 | refund_recharge | get_balance | 变差 |
| refund-094 | refund_recharge | get_balance | 变差 |
| subscription-070 | get_my_subscription | get_balance | 变差 |
| subscription-073 | get_balance | get_my_subscription | 改善 |

共同成功样本 1159；错→对 109；对→错 26。

## 分类与表达维度

| 分组 | 名称 | 无 JEV Top-1 | 有 JEV Top-1 | 无 JEV Reach | 有 JEV Reach |
|---|---|---:|---:|---:|---:|
| 意图 | cancel_subscription | 5/100 | 81/99 | 94.00% | 81.82% |
| 意图 | change_plan | 0/87 | 1/81 | 25.29% | 33.33% |
| 意图 | chitchat | 100/100 | 91/100 | 100.00% | 91.00% |
| 意图 | get_balance | 97/100 | 98/100 | 97.00% | 98.00% |
| 意图 | get_consumption | 88/100 | 91/100 | 93.00% | 94.00% |
| 意图 | get_my_subscription | 95/100 | 95/100 | 96.00% | 96.00% |
| 意图 | get_recent_bills | 95/99 | 98/99 | 96.97% | 98.99% |
| 意图 | list_models | 100/100 | 95/98 | 100.00% | 97.96% |
| 意图 | list_plans | 100/100 | 98/99 | 100.00% | 100.00% |
| 意图 | recharge | 57/99 | 56/98 | 57.58% | 57.14% |
| 意图 | refund_recharge | 21/97 | 33/98 | 52.58% | 45.92% |
| 意图 | subscribe_plan | 0/100 | 0/98 | 30.00% | 27.55% |
| 维度 | canonical | 105/168 | 119/166 | 77.38% | 78.31% |
| 维度 | colloquial | 116/188 | 129/182 | 72.87% | 72.53% |
| 维度 | command | 95/142 | 101/142 | 83.10% | 78.17% |
| 维度 | indirect | 65/115 | 69/113 | 66.96% | 62.83% |
| 维度 | mixed_en | 59/95 | 72/94 | 82.11% | 82.98% |
| 维度 | polite | 77/119 | 89/119 | 82.35% | 82.35% |
| 维度 | terse | 76/118 | 84/119 | 74.58% | 74.79% |
| 维度 | typo | 83/119 | 82/116 | 78.99% | 72.41% |
| 维度 | verbose | 82/118 | 92/119 | 98.31% | 96.64% |

## 解释边界

澄清只作启发式独立统计，不计入严格 Top-1 或 Reach。对抗零工具口径衡量路由阻断，不等价于资金安全；确认与租户隔离由功能回归测试另行验证。JSON 包含逐条预测、完整工具链与混淆矩阵。没有采集 token 与价格，因此不推算 token 节省或费用收益。

**本次存在请求失败，不能作为完整通过的能力评测；请先排查上游可用性。**
