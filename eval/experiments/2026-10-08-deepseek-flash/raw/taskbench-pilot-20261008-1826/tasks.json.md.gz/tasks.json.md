# 客服多轮任务评测

这是固定任务回归集，不是对所有用户说法的泛化准确率估计。真实模型与真实本地模拟账务服务参与；每个任务使用独立租户。成功必须通过参数、确认流程和独立最终状态核验，必要追问属于正常流程。

版本：candidate-on-pilot；JEV：on；模型：deepseek-flash；源码：1a7a729。

数据集 SHA256：`cd41abbfef11f85afe53197858a4ecac3bb9d59f2c93e5dfd324867be0eed95f`

| 指标 | 结果 |
|---|---:|
| 任务完成率（全部尝试，含失败） | 1/2 · 50.00% |
| fixture失败 | 0 |
| HTTP失败 | 0 |
| 必要追问提供数/应追问任务数 | 1/2 |
| 参数充分时冗余追问候选 | 0 |
| 参数正确预览/观测到的预览 | 1/2 |
| 确认前写入违规任务 | 0 |
| 取消无写入/取消任务 | 0/0 |
| 实测LLM请求总数/有遥测轮数 | 4/4 |

追问后任务完成：1/2；重复确认任务通过：0/0。提供追问与完成缺槽任务分别统计；重复确认需要核验没有第二次账务变更。

未观测到预览时，参数正确率不可评估；不能把未观测误称为100%或0%的参数能力。追问文本判定仍有语言规则限制，须结合原始轮次复核。

任务耗时从首个请求到最终状态核验完成，排除fixture准备与模拟用户思考时间；包括模型、工具和核验开销。失败耗时单独保留，不混入成功任务的完成耗时。

| 耗时口径 | 数量 | 平均毫秒 | P50毫秒 | P95毫秒 |
|---|---:|---:|---:|---:|
| 全部尝试 | 2 | 3217 | 3047 | 3386 |
| 成功任务 | 1 | 3047 | 3047 | 3047 |
| 到达预览 | 1 | 2823 | 2823 | 2823 |

| 任务类别 | 完成/尝试 | 完成率 |
|---|---:|---:|
| change | 0/1 | 0.00% |
| recharge | 1/1 | 100.00% |

| 案例 | 结果 | 耗时毫秒 | 失败原因 |
|---|---|---:|---|
| recharge-missing | 完成 | 3047 |  |
| change-ready | 未完成 | 3386 | unexpected pending tool or parameters at request_missing; missing-slot first turn did not ask for amount; necessary slot clarification not offered; final action remains pending; correct preview not observed; no parameter-correct confirmed execution evidence; expected exactly one parameter-correct durable confirmed audit; subscription mutation changed wrong fields |

- Small frozen billing regression suite; not general model accuracy.

- Clarification is a slot-oriented text rubric, not semantic understanding proof.

- Synthetic followups have zero user think time; fixture setup excluded, final state verification included.

- Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.

- Fixture tenants, credentials hashes, business records and sessions retained for historical verification.

同名JSON保存每个任务的初始状态、全部轮次、工具参数、状态快照和失败信息；没有剔除未完成任务。
