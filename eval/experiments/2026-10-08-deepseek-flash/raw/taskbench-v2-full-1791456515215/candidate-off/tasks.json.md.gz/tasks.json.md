评分规则：`taskbench.v2`。

# 客服多轮任务评测

这是固定任务回归集，不是对所有用户说法的泛化准确率估计。真实模型与真实本地模拟账务服务参与；每个任务使用独立租户。成功必须通过参数、确认流程和独立最终状态核验，必要追问属于正常流程。

版本：candidate-off；JEV：off；模型：deepseek-flash；源码：d07e671f1ab4eaa7f1f8a5d3e3bc3711f129094b。

数据集 SHA256：`ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9`

| 指标 | 结果 |
|---|---:|
| 任务完成率（全部尝试，含失败） | 24/24 · 100.00% |
| fixture失败 | 0 |
| HTTP失败 | 0 |
| 必要追问提供数/应追问任务数 | 4/4 |
| 参数充分时冗余追问候选 | 3 |
| 参数正确预览/观测到的预览 | 19/19 |
| 确认前写入违规任务 | 0 |
| 取消无写入/取消任务 | 5/5 |
| 实测LLM请求总数/有遥测轮数 | 39/48 |

追问后任务完成：4/4；重复确认任务通过：1/1。提供追问与完成缺槽任务分别统计；重复确认需要核验没有第二次账务变更。

取消后的账务状态未变观测：5/5；成功取消且无写入（同时要求清除挂起）：5/5。状态未变不能替代取消成功，仍挂起的操作以后可能被确认。

未观测到预览时，参数正确率不可评估；不能把未观测误称为100%或0%的参数能力。追问文本判定仍有语言规则限制，须结合原始轮次复核。

任务耗时从首个请求到最终状态核验完成，排除fixture准备与模拟用户思考时间；包括模型、工具和核验开销。失败耗时单独保留，不混入成功任务的完成耗时。

| 耗时口径 | 数量 | 平均毫秒 | P50毫秒 | P95毫秒 |
|---|---:|---:|---:|---:|
| 全部尝试 | 24 | 2179 | 1700 | 3733 |
| 成功任务 | 24 | 2179 | 1700 | 3733 |
| 到达预览 | 19 | 1860 | 1508 | 4250 |

| 任务类别 | 完成/尝试 | 完成率 |
|---|---:|---:|
| already_satisfied | 3/3 | 100.00% |
| cancel_subscription | 2/2 | 100.00% |
| change | 3/3 | 100.00% |
| read | 2/2 | 100.00% |
| recharge | 4/4 | 100.00% |
| refund | 6/6 | 100.00% |
| subscribe | 4/4 | 100.00% |

| 案例 | 结果 | 耗时毫秒 | 失败原因 |
|---|---|---:|---|
| recharge-ready | 完成 | 1180 |  |
| recharge-missing | 完成 | 1641 |  |
| recharge-cancel | 完成 | 1786 |  |
| recharge-repeat | 完成 | 3556 |  |
| refund-ready | 完成 | 1384 |  |
| refund-missing | 完成 | 3037 |  |
| refund-cancel | 完成 | 1287 |  |
| refund-composite | 完成 | 2770 |  |
| refund-order | 完成 | 2059 |  |
| subscribe-ready | 完成 | 1112 |  |
| subscribe-missing | 完成 | 3194 |  |
| subscribe-cancel | 完成 | 4982 |  |
| subscribe-flagship | 完成 | 3212 |  |
| change-ready | 完成 | 3249 |  |
| change-missing | 完成 | 3733 |  |
| change-cancel | 完成 | 1423 |  |
| cancel-subscription | 完成 | 1002 |  |
| cancel-abort | 完成 | 1660 |  |
| balance-read | 完成 | 1700 |  |
| subscription-read | 完成 | 1591 |  |
| satisfied-balance | 完成 | 1676 |  |
| satisfied-subscription | 完成 | 2179 |  |
| refund-capped | 完成 | 1134 |  |
| cancelled-read | 完成 | 1753 |  |

- Small frozen billing regression suite; not general model accuracy.

- Clarification is a slot-oriented text rubric, not semantic understanding proof.

- Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.

- Synthetic followups have zero user think time; fixture setup excluded, final state verification included.

- Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.

- Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.

- Fixture tenants, credentials hashes, business records and sessions retained for historical verification.

同名JSON保存每个任务的初始状态、全部轮次、工具参数、状态快照和失败信息；没有剔除未完成任务。
