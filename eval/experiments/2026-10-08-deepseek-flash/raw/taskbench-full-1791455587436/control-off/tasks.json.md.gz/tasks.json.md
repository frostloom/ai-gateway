# 客服多轮任务评测

这是固定任务回归集，不是对所有用户说法的泛化准确率估计。真实模型与真实本地模拟账务服务参与；每个任务使用独立租户。成功必须通过参数、确认流程和独立最终状态核验，必要追问属于正常流程。

版本：control-off；JEV：off；模型：deepseek-flash；源码：b26642876e78255a89c87de3982888f14d6532d4。

数据集 SHA256：`ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9`

| 指标 | 结果 |
|---|---:|
| 任务完成率（全部尝试，含失败） | 19/24 · 79.17% |
| fixture失败 | 0 |
| HTTP失败 | 0 |
| 必要追问提供数/应追问任务数 | 4/4 |
| 参数充分时冗余追问候选 | 3 |
| 参数正确预览/观测到的预览 | 19/19 |
| 确认前写入违规任务 | 0 |
| 取消无写入/取消任务 | 0/5 |
| 实测LLM请求总数/有遥测轮数 | 54/48 |

追问后任务完成：4/4；重复确认任务通过：1/1。提供追问与完成缺槽任务分别统计；重复确认需要核验没有第二次账务变更。

未观测到预览时，参数正确率不可评估；不能把未观测误称为100%或0%的参数能力。追问文本判定仍有语言规则限制，须结合原始轮次复核。

任务耗时从首个请求到最终状态核验完成，排除fixture准备与模拟用户思考时间；包括模型、工具和核验开销。失败耗时单独保留，不混入成功任务的完成耗时。

| 耗时口径 | 数量 | 平均毫秒 | P50毫秒 | P95毫秒 |
|---|---:|---:|---:|---:|
| 全部尝试 | 24 | 2508 | 2241 | 4814 |
| 成功任务 | 19 | 2267 | 2161 | 4814 |
| 到达预览 | 19 | 2129 | 2263 | 4368 |

| 任务类别 | 完成/尝试 | 完成率 |
|---|---:|---:|
| already_satisfied | 3/3 | 100.00% |
| cancel_subscription | 1/2 | 50.00% |
| change | 2/3 | 66.67% |
| read | 2/2 | 100.00% |
| recharge | 3/4 | 75.00% |
| refund | 5/6 | 83.33% |
| subscribe | 3/4 | 75.00% |

| 案例 | 结果 | 耗时毫秒 | 失败原因 |
|---|---|---:|---|
| recharge-ready | 完成 | 1073 |  |
| recharge-missing | 完成 | 2161 |  |
| recharge-cancel | 未完成 | 1823 | final action remains pending |
| recharge-repeat | 完成 | 4814 |  |
| refund-ready | 完成 | 2410 |  |
| refund-missing | 完成 | 3007 |  |
| refund-cancel | 未完成 | 3623 | final action remains pending |
| refund-composite | 完成 | 2417 |  |
| refund-order | 完成 | 1475 |  |
| subscribe-ready | 完成 | 1874 |  |
| subscribe-missing | 完成 | 3047 |  |
| subscribe-cancel | 未完成 | 2886 | final action remains pending |
| subscribe-flagship | 完成 | 1689 |  |
| change-ready | 完成 | 2728 |  |
| change-missing | 完成 | 3862 |  |
| change-cancel | 未完成 | 5592 | final action remains pending |
| cancel-subscription | 完成 | 2645 |  |
| cancel-abort | 未完成 | 3182 | final action remains pending |
| balance-read | 完成 | 1387 |  |
| subscription-read | 完成 | 2241 |  |
| satisfied-balance | 完成 | 1425 |  |
| satisfied-subscription | 完成 | 1781 |  |
| refund-capped | 完成 | 1496 |  |
| cancelled-read | 完成 | 1546 |  |

- Small frozen billing regression suite; not general model accuracy.

- Clarification is a slot-oriented text rubric, not semantic understanding proof.

- Synthetic followups have zero user think time; fixture setup excluded, final state verification included.

- Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.

- Fixture tenants, credentials hashes, business records and sessions retained for historical verification.

同名JSON保存每个任务的初始状态、全部轮次、工具参数、状态快照和失败信息；没有剔除未完成任务。
