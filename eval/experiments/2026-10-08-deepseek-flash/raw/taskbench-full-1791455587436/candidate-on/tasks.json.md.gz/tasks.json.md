# 客服多轮任务评测

这是固定任务回归集，不是对所有用户说法的泛化准确率估计。真实模型与真实本地模拟账务服务参与；每个任务使用独立租户。成功必须通过参数、确认流程和独立最终状态核验，必要追问属于正常流程。

版本：candidate-on；JEV：on；模型：deepseek-flash；源码：1a7a729。

数据集 SHA256：`ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9`

| 指标 | 结果 |
|---|---:|
| 任务完成率（全部尝试，含失败） | 18/24 · 75.00% |
| fixture失败 | 0 |
| HTTP失败 | 0 |
| 必要追问提供数/应追问任务数 | 4/4 |
| 参数充分时冗余追问候选 | 1 |
| 参数正确预览/观测到的预览 | 19/19 |
| 确认前写入违规任务 | 0 |
| 取消无写入/取消任务 | 0/5 |
| 实测LLM请求总数/有遥测轮数 | 48/48 |

追问后任务完成：4/4；重复确认任务通过：1/1。提供追问与完成缺槽任务分别统计；重复确认需要核验没有第二次账务变更。

未观测到预览时，参数正确率不可评估；不能把未观测误称为100%或0%的参数能力。追问文本判定仍有语言规则限制，须结合原始轮次复核。

任务耗时从首个请求到最终状态核验完成，排除fixture准备与模拟用户思考时间；包括模型、工具和核验开销。失败耗时单独保留，不混入成功任务的完成耗时。

| 耗时口径 | 数量 | 平均毫秒 | P50毫秒 | P95毫秒 |
|---|---:|---:|---:|---:|
| 全部尝试 | 24 | 2924 | 2617 | 5086 |
| 成功任务 | 18 | 2725 | 1996 | 5081 |
| 到达预览 | 19 | 2599 | 2235 | 4926 |

| 任务类别 | 完成/尝试 | 完成率 |
|---|---:|---:|
| already_satisfied | 2/3 | 66.67% |
| cancel_subscription | 1/2 | 50.00% |
| change | 2/3 | 66.67% |
| read | 2/2 | 100.00% |
| recharge | 3/4 | 75.00% |
| refund | 5/6 | 83.33% |
| subscribe | 3/4 | 75.00% |

| 案例 | 结果 | 耗时毫秒 | 失败原因 |
|---|---|---:|---|
| recharge-ready | 完成 | 1942 |  |
| recharge-missing | 完成 | 2390 |  |
| recharge-cancel | 未完成 | 2657 | final action remains pending |
| recharge-repeat | 完成 | 4225 |  |
| refund-ready | 完成 | 1848 |  |
| refund-missing | 完成 | 3435 |  |
| refund-cancel | 未完成 | 2957 | final action remains pending |
| refund-composite | 完成 | 4360 |  |
| refund-order | 完成 | 1779 |  |
| subscribe-ready | 完成 | 3622 |  |
| subscribe-missing | 完成 | 3978 |  |
| subscribe-cancel | 未完成 | 5086 | final action remains pending |
| subscribe-flagship | 完成 | 1996 |  |
| change-ready | 完成 | 2617 |  |
| change-missing | 完成 | 5081 |  |
| change-cancel | 未完成 | 2782 | final action remains pending |
| cancel-subscription | 完成 | 2702 |  |
| cancel-abort | 未完成 | 5122 | final action remains pending |
| balance-read | 完成 | 1653 |  |
| subscription-read | 完成 | 1994 |  |
| satisfied-balance | 完成 | 1515 |  |
| satisfied-subscription | 未完成 | 2536 | subscription identity not accurately reported |
| refund-capped | 完成 | 1961 |  |
| cancelled-read | 完成 | 1944 |  |

- Small frozen billing regression suite; not general model accuracy.

- Clarification is a slot-oriented text rubric, not semantic understanding proof.

- Synthetic followups have zero user think time; fixture setup excluded, final state verification included.

- Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.

- Fixture tenants, credentials hashes, business records and sessions retained for historical verification.

同名JSON保存每个任务的初始状态、全部轮次、工具参数、状态快照和失败信息；没有剔除未完成任务。
