# 客服多轮任务评测

这是固定任务回归集，不是对所有用户说法的泛化准确率估计。真实模型与真实本地模拟账务服务参与；每个任务使用独立租户。成功必须通过参数、确认流程和独立最终状态核验，必要追问属于正常流程。

版本：control-on；JEV：on；模型：deepseek-flash；源码：b26642876e78255a89c87de3982888f14d6532d4。

数据集 SHA256：`ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9`

| 指标 | 结果 |
|---|---:|
| 任务完成率（全部尝试，含失败） | 17/24 · 70.83% |
| fixture失败 | 0 |
| HTTP失败 | 0 |
| 必要追问提供数/应追问任务数 | 4/4 |
| 参数充分时冗余追问候选 | 2 |
| 参数正确预览/观测到的预览 | 19/19 |
| 确认前写入违规任务 | 0 |
| 取消无写入/取消任务 | 0/5 |
| 实测LLM请求总数/有遥测轮数 | 50/48 |

追问后任务完成：4/4；重复确认任务通过：1/1。提供追问与完成缺槽任务分别统计；重复确认需要核验没有第二次账务变更。

未观测到预览时，参数正确率不可评估；不能把未观测误称为100%或0%的参数能力。追问文本判定仍有语言规则限制，须结合原始轮次复核。

任务耗时从首个请求到最终状态核验完成，排除fixture准备与模拟用户思考时间；包括模型、工具和核验开销。失败耗时单独保留，不混入成功任务的完成耗时。

| 耗时口径 | 数量 | 平均毫秒 | P50毫秒 | P95毫秒 |
|---|---:|---:|---:|---:|
| 全部尝试 | 24 | 2932 | 2680 | 4934 |
| 成功任务 | 17 | 2875 | 2680 | 4941 |
| 到达预览 | 19 | 2495 | 2223 | 4788 |

| 任务类别 | 完成/尝试 | 完成率 |
|---|---:|---:|
| already_satisfied | 2/3 | 66.67% |
| cancel_subscription | 1/2 | 50.00% |
| change | 2/3 | 66.67% |
| read | 1/2 | 50.00% |
| recharge | 3/4 | 75.00% |
| refund | 5/6 | 83.33% |
| subscribe | 3/4 | 75.00% |

| 案例 | 结果 | 耗时毫秒 | 失败原因 |
|---|---|---:|---|
| recharge-ready | 完成 | 1833 |  |
| recharge-missing | 完成 | 3639 |  |
| recharge-cancel | 未完成 | 2667 | final action remains pending |
| recharge-repeat | 完成 | 4941 |  |
| refund-ready | 完成 | 3059 |  |
| refund-missing | 完成 | 3860 |  |
| refund-cancel | 未完成 | 3627 | final action remains pending |
| refund-composite | 完成 | 2719 |  |
| refund-order | 完成 | 1896 |  |
| subscribe-ready | 完成 | 2157 |  |
| subscribe-missing | 完成 | 4289 |  |
| subscribe-cancel | 未完成 | 3810 | final action remains pending |
| subscribe-flagship | 完成 | 2325 |  |
| change-ready | 完成 | 3081 |  |
| change-missing | 完成 | 4934 |  |
| change-cancel | 未完成 | 3675 | final action remains pending |
| cancel-subscription | 完成 | 1719 |  |
| cancel-abort | 未完成 | 2562 | final action remains pending |
| balance-read | 完成 | 1568 |  |
| subscription-read | 未完成 | 2436 | subscription identity not accurately reported |
| satisfied-balance | 完成 | 2140 |  |
| satisfied-subscription | 未完成 | 2701 | subscription identity not accurately reported |
| refund-capped | 完成 | 2680 |  |
| cancelled-read | 完成 | 2040 |  |

- Small frozen billing regression suite; not general model accuracy.

- Clarification is a slot-oriented text rubric, not semantic understanding proof.

- Synthetic followups have zero user think time; fixture setup excluded, final state verification included.

- Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.

- Fixture tenants, credentials hashes, business records and sessions retained for historical verification.

同名JSON保存每个任务的初始状态、全部轮次、工具参数、状态快照和失败信息；没有剔除未完成任务。
