# Multi-turn task efficiency comparison

Original completion and clarification rubric retained. All failures and usage completeness remain visible.

```json
{
  "schema": "taskbench.efficiency.v1",
  "dataset_sha256": "ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9",
  "actual_cases_sha256": "da1b4b09e83f8acfbc328cf322314028ea374b6d1ec742cd1c692a7c85868017",
  "actual_cases": [
    {
      "id": "balance-read",
      "category": "read",
      "message": "我的账户现在还有多少余额？",
      "tool": "get_balance",
      "initial_subscription": false,
      "cancel": false,
      "read": true
    },
    {
      "id": "cancel-abort",
      "category": "cancel_subscription",
      "message": "退订当前套餐",
      "tool": "cancel_subscription",
      "initial_subscription": true,
      "cancel": true,
      "read": false
    },
    {
      "id": "cancel-subscription",
      "category": "cancel_subscription",
      "message": "退订我的定期订阅，停止下期自动续费",
      "tool": "cancel_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "cancelled-read",
      "category": "already_satisfied",
      "message": "只查询我现在还有没有生效中的定期订阅，不要重新订购",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "initially_cancelled": true,
      "cancel": false,
      "read": true
    },
    {
      "id": "change-cancel",
      "category": "change",
      "message": "把套餐改成月度·旗舰",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": true,
      "read": false
    },
    {
      "id": "change-missing",
      "category": "change",
      "message": "我要改套餐",
      "followup": "改成月度·旗舰套餐",
      "missing_slot": "plan",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "change-ready",
      "category": "change",
      "message": "把我当前的套餐改成月度·旗舰",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-cancel",
      "category": "recharge",
      "message": "充值100元",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "recharge-missing",
      "category": "recharge",
      "message": "我要充值",
      "followup": "充值100元",
      "missing_slot": "amount",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-ready",
      "category": "recharge",
      "message": "给我的账户充值100元",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-repeat",
      "category": "recharge",
      "message": "帮我充200元",
      "tool": "recharge",
      "amount_money": 200,
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "duplicate_confirm": true
    },
    {
      "id": "refund-cancel",
      "category": "refund",
      "message": "退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "refund-capped",
      "category": "refund",
      "message": "按金额退款6000元，最多退到当前余额",
      "tool": "refund_recharge",
      "amount_money": 6000,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "refund-composite",
      "category": "refund",
      "message": "先查一下余额，然后帮我退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "require_balance_answer": true
    },
    {
      "id": "refund-missing",
      "category": "refund",
      "message": "我要退款",
      "followup": "按金额退款100元",
      "missing_slot": "amount",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "refund-order",
      "category": "refund",
      "message": "退掉已支付的充值订单{order_no}",
      "tool": "refund_recharge",
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "order_refund": true
    },
    {
      "id": "refund-ready",
      "category": "refund",
      "message": "请给我退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "satisfied-balance",
      "category": "already_satisfied",
      "message": "只查询余额，不充值也不退款",
      "tool": "get_balance",
      "initial_subscription": false,
      "cancel": false,
      "read": true
    },
    {
      "id": "satisfied-subscription",
      "category": "already_satisfied",
      "message": "我已经有月度·标准套餐，请查看当前订阅，不要重复订购",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": true
    },
    {
      "id": "subscribe-cancel",
      "category": "subscribe",
      "message": "订购月度·标准套餐",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "subscribe-flagship",
      "category": "subscribe",
      "message": "开通月度·旗舰订阅",
      "tool": "subscribe_plan",
      "plan": "flagship",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscribe-missing",
      "category": "subscribe",
      "message": "我要订购一个套餐",
      "followup": "订购月度·标准套餐",
      "missing_slot": "plan",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscribe-ready",
      "category": "subscribe",
      "message": "给我订购月度·标准套餐",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscription-read",
      "category": "read",
      "message": "查看我当前的订阅套餐",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": true
    }
  ],
  "task_count": 24,
  "runs": {
    "baseline": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 95453,
          "llm_output_tokens": 4749,
          "llm_cache_hit_tokens": 87808,
          "llm_cache_miss_tokens": 7645,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 42,
        "usage_responses": 42,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "openai": 29,
          "unreported": 19
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 0,
          "jev_output_tokens": 0
        },
        "usage_responses": 0,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.008519148,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.006,
          "cache_miss_input_per_million": 0.3,
          "output_per_million": 1.2,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 95453,
          "llm_output_tokens": 4749,
          "llm_cache_hit_tokens": 87808,
          "llm_cache_miss_tokens": 7645,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 0,
          "jev_output_tokens": 0
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 0,
        "llm_estimate": 0.008519148,
        "jev_estimate": 0.0
      },
      "llm_attempts_complete": true,
      "turn_attempts": 48,
      "request_latency_all_ms": {
        "count": 48,
        "average": 924.3818854166667,
        "p50": 837.2198,
        "p95": 3101.9249
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 24,
        "completion_rate": 1,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 2,
        "preview_observed": 19,
        "preview_correct": 19,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 5,
        "cancel_no_write_observed": 5,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 42,
        "telemetry_turns": 48,
        "all_task_latency": {
          "count": 24,
          "average_ms": 1989.9916875000001,
          "p50_ms": 1570.5655,
          "p95_ms": 3594.5247
        },
        "successful_task_latency": {
          "count": 24,
          "average_ms": 1989.9916875000001,
          "p50_ms": 1570.5655,
          "p95_ms": 3594.5247
        },
        "time_to_preview": {
          "count": 19,
          "average_ms": 1761.0676842105267,
          "p50_ms": 1401.6826,
          "p95_ms": 3642.8861
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-revised-nojev",
        "jev_mode": "off",
        "model": "deepseek-flash",
        "source_git": "f2b62e5eab0e8db61065f2f45db589d382bd37ab",
        "binary_sha256": "4a14ba252dd9744d6ecdf74d8a2696e00ebdb916a4359b871ec08d019951914f",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4455,
              "llm_output_tokens": 55,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 359,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000198276,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4455,
              "llm_output_tokens": 55,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 359,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000198276,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1368.7085,
            "p50": 1368.7085,
            "p95": 1368.7085
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1455.4678,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 348,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4455,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 359,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000198276,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4455,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 359,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000198276,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1368.7085,
                "p50": 1368.7085,
                "p95": 1368.7085
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4614,
              "llm_output_tokens": 189,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 390,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000369144,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4614,
              "llm_output_tokens": 189,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 390,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000369144,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 856.3011,
            "p50": 46.1811,
            "p95": 1666.4211
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1860.0075,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1721.6429,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 346,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 46.1811,
                "p50": 46.1811,
                "p95": 46.1811
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 189,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000369144,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 189,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000369144,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1666.4211,
                "p50": 1666.4211,
                "p95": 1666.4211
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 150,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000237588,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 150,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000237588,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 707.88675,
            "p50": 61.834,
            "p95": 1353.9395
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1554.8821,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1401.6826,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 343,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.834,
                "p50": 61.834,
                "p95": 61.834
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 150,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000237588,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 150,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000237588,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1353.9395,
                "p50": 1353.9395,
                "p95": 1353.9395
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4458,
              "llm_output_tokens": 76,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 362,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022437599999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4458,
              "llm_output_tokens": 76,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 362,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00022437599999999998,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1511.4467,
            "p50": 1511.4467,
            "p95": 1511.4467
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1607.4785,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 358,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4458,
                  "llm_output_tokens": 76,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 362,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022437599999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4458,
                  "llm_output_tokens": 76,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 362,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00022437599999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1511.4467,
                "p50": 1511.4467,
                "p95": 1511.4467
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2193,
              "llm_output_tokens": 88,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 145,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00016138799999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2193,
              "llm_output_tokens": 88,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 145,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00016138799999999997,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 493.7138,
            "p50": 51.0385,
            "p95": 936.3891
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1135.1863,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 985.6929,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 342,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 51.0385,
                "p50": 51.0385,
                "p95": 51.0385
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2193,
                  "llm_output_tokens": 88,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 145,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00016138799999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2193,
                  "llm_output_tokens": 88,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 145,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00016138799999999997,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 936.3891,
                "p50": 936.3891,
                "p95": 936.3891
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7154,
              "llm_output_tokens": 310,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 754,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0006365999999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7154,
              "llm_output_tokens": 310,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 754,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0006365999999999999,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1005.9926333333334,
            "p50": 1121.8275,
            "p95": 1832.0018
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3214.6813,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3051.2364,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 338,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 64.1486,
                "p50": 64.1486,
                "p95": 64.1486
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4617,
                  "llm_output_tokens": 251,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 393,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00044444399999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4617,
                  "llm_output_tokens": 251,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 393,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00044444399999999995,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1832.0018,
                "p50": 1832.0018,
                "p95": 1832.0018
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2537,
                  "llm_output_tokens": 59,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 361,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000192156,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2537,
                  "llm_output_tokens": 59,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 361,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000192156,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1121.8275,
                "p50": 1121.8275,
                "p95": 1121.8275
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2194,
              "llm_output_tokens": 141,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 146,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022528799999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2194,
              "llm_output_tokens": 141,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 146,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00022528799999999997,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 509.15524999999997,
            "p50": 67.9585,
            "p95": 950.352
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1169.5838,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1007.45,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 336,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 67.9585,
                "p50": 67.9585,
                "p95": 67.9585
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2194,
                  "llm_output_tokens": 141,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 146,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022528799999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2194,
                  "llm_output_tokens": 141,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 146,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00022528799999999997,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 950.352,
                "p50": 950.352,
                "p95": 950.352
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 75,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000144888,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 75,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000144888,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 466.41790000000003,
            "p50": 44.7335,
            "p95": 888.1023
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1059.7439,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 931.0025,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 306,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 44.7335,
                "p50": 44.7335,
                "p95": 44.7335
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 75,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000144888,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 75,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000144888,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 888.1023,
                "p50": 888.1023,
                "p95": 888.1023
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4395,
              "llm_output_tokens": 81,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 299,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000211476,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4395,
              "llm_output_tokens": 81,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 299,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000211476,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 571.1964666666667,
            "p50": 770.1567,
            "p95": 837.2198
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1936.7528,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1723.2149,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 303,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 106.2129,
                "p50": 106.2129,
                "p95": 106.2129
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 24,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 8.3388e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 24,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 8.3388e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 770.1567,
                "p50": 770.1567,
                "p95": 770.1567
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2206,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 158,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000128088,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2206,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 158,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000128088,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 837.2198,
                "p50": 837.2198,
                "p95": 837.2198
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000131088,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000131088,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 427.18105,
            "p50": 99.1438,
            "p95": 755.2183
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 995.8079,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 807.5711,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 302,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 99.1438,
                "p50": 99.1438,
                "p95": 99.1438
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000131088,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000131088,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 755.2183,
                "p50": 755.2183,
                "p95": 755.2183
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7004,
              "llm_output_tokens": 364,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 604,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0006564,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7004,
              "llm_output_tokens": 364,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 604,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0006564,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 998.9986333333333,
            "p50": 457.1431,
            "p95": 2448.3468
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3199.2451,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 501.176,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 308,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 91.506,
                "p50": 91.506,
                "p95": 91.506
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4813,
                  "llm_output_tokens": 307,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 461,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0005328119999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4813,
                  "llm_output_tokens": 307,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 461,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0005328119999999999,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2448.3468,
                "p50": 2448.3468,
                "p95": 2448.3468
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2191,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 143,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000123588,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2191,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 143,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000123588,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 457.1431,
                "p50": 457.1431,
                "p95": 457.1431
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 135,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00021688800000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 135,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00021688800000000001,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 715.1323,
            "p50": 46.9052,
            "p95": 1383.3594
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1570.5655,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1439.5746,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 316,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 46.9052,
                "p50": 46.9052,
                "p95": 46.9052
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 135,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00021688800000000001,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 135,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00021688800000000001,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1383.3594,
                "p50": 1383.3594,
                "p95": 1383.3594
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000201588,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000201588,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 630.5767500000001,
            "p50": 60.2134,
            "p95": 1200.9401
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1390.607,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1242.369,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 357,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 60.2134,
                "p50": 60.2134,
                "p95": 60.2134
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000201588,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000201588,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1200.9401,
                "p50": 1200.9401,
                "p95": 1200.9401
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2197,
              "llm_output_tokens": 726,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 149,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0009281879999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2197,
              "llm_output_tokens": 726,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 149,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0009281879999999998,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1826.57395,
            "p50": 68.9959,
            "p95": 3584.152
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3799.2776,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3642.8861,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 319,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 68.9959,
                "p50": 68.9959,
                "p95": 68.9959
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2197,
                  "llm_output_tokens": 726,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0009281879999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2197,
                  "llm_output_tokens": 726,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0009281879999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3584.152,
                "p50": 3584.152,
                "p95": 3584.152
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4459,
              "llm_output_tokens": 189,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 363,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000360276,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4459,
              "llm_output_tokens": 189,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 363,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000360276,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 631.7290333333333,
            "p50": 875.0076,
            "p95": 958.7827
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2075.8686,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1921.8073,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 313,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.3968,
                "p50": 61.3968,
                "p95": 61.3968
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 94,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00016738799999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 94,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00016738799999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 958.7827,
                "p50": 958.7827,
                "p95": 958.7827
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 95,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00019288799999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 95,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00019288799999999997,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 875.0076,
                "p50": 875.0076,
                "p95": 875.0076
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2215,
              "llm_output_tokens": 134,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 167,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022318799999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2215,
              "llm_output_tokens": 134,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 167,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00022318799999999998,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 609.3187,
            "p50": 69.6186,
            "p95": 1149.0188
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1344.6301,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1191.9066,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 323,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.6186,
                "p50": 69.6186,
                "p95": 69.6186
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2215,
                  "llm_output_tokens": 134,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 167,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022318799999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2215,
                  "llm_output_tokens": 134,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 167,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00022318799999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1149.0188,
                "p50": 1149.0188,
                "p95": 1149.0188
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 131,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000212688,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 131,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000212688,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 623.1792,
            "p50": 61.6049,
            "p95": 1184.7535
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1372.0238,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1229.5523,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 312,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.6049,
                "p50": 61.6049,
                "p95": 61.6049
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 131,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000212688,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 131,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000212688,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1184.7535,
                "p50": 1184.7535,
                "p95": 1184.7535
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4458,
              "llm_output_tokens": 61,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 362,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00020637599999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4458,
              "llm_output_tokens": 61,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 362,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00020637599999999998,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 903.1398,
            "p50": 903.1398,
            "p95": 903.1398
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 976.9592,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 351,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4458,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 362,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00020637599999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4458,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 362,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00020637599999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 903.1398,
                "p50": 903.1398,
                "p95": 903.1398
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4571,
              "llm_output_tokens": 337,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 347,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0005338439999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4571,
              "llm_output_tokens": 337,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 347,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0005338439999999999,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2840.6662,
            "p50": 2840.6662,
            "p95": 2840.6662
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2942.1167,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 353,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4571,
                  "llm_output_tokens": 337,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 347,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0005338439999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4571,
                  "llm_output_tokens": 337,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 347,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0005338439999999999,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2840.6662,
                "p50": 2840.6662,
                "p95": 2840.6662
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7061,
              "llm_output_tokens": 440,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 533,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000727068,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7061,
              "llm_output_tokens": 440,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 533,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000727068,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1736.8678,
            "p50": 44.6253,
            "p95": 3429.1103
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3594.5247,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3472.2728,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 332,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 44.6253,
                "p50": 44.6253,
                "p95": 44.6253
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7061,
                  "llm_output_tokens": 440,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 533,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000727068,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7061,
                  "llm_output_tokens": 440,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 533,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000727068,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3429.1103,
                "p50": 3429.1103,
                "p95": 3429.1103
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 227,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000327888,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 227,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000327888,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 625.8207,
            "p50": 86.4553,
            "p95": 1165.1861
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1413.3219,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1222.8714,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 335,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 86.4553,
                "p50": 86.4553,
                "p95": 86.4553
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 227,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000327888,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 227,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000327888,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1165.1861,
                "p50": 1165.1861,
                "p95": 1165.1861
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7157,
              "llm_output_tokens": 311,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 757,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0006387000000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7157,
              "llm_output_tokens": 311,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 757,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0006387000000000001,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 931.7049666666667,
            "p50": 735.1096,
            "p95": 1998.8623
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2989.6191,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2824.5702,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 329,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.143,
                "p50": 61.143,
                "p95": 61.143
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4597,
                  "llm_output_tokens": 249,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 373,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00043604399999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4597,
                  "llm_output_tokens": 249,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 373,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00043604399999999996,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1998.8623,
                "p50": 1998.8623,
                "p95": 1998.8623
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2560,
                  "llm_output_tokens": 62,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 384,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000202656,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2560,
                  "llm_output_tokens": 62,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 384,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000202656,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 735.1096,
                "p50": 735.1096,
                "p95": 735.1096
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 6981,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 581,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00042029999999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 6981,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 581,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00042029999999999997,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1583.49385,
            "p50": 65.0628,
            "p95": 3101.9249
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3304.0892,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3141.8064,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 325,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 65.0628,
                "p50": 65.0628,
                "p95": 65.0628
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 6981,
                  "llm_output_tokens": 173,
                  "llm_cache_hit_tokens": 6400,
                  "llm_cache_miss_tokens": 581,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00042029999999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 6981,
                  "llm_output_tokens": 173,
                  "llm_cache_hit_tokens": 6400,
                  "llm_cache_miss_tokens": 581,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00042029999999999997,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3101.9249,
                "p50": 3101.9249,
                "p95": 3101.9249
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4533,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 309,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000325644,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4533,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 309,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000325644,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1704.2659,
            "p50": 1704.2659,
            "p95": 1704.2659
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1797.3601,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 349,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4533,
                  "llm_output_tokens": 173,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 309,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000325644,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4533,
                  "llm_output_tokens": 173,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 309,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000325644,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1704.2659,
                "p50": 1704.2659,
                "p95": 1704.2659
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 1989.9916875,
        "p50": 1570.5655,
        "p95": 3594.5247
      },
      "latency_successful_tasks_ms": {
        "count": 24,
        "average": 1989.9916875,
        "p50": 1570.5655,
        "p95": 3594.5247
      },
      "failure_details": [],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 5
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 5,
          "request_latency_all_ms": {
            "count": 5,
            "average": 46.69672,
            "p50": 46.1811,
            "p95": 51.0385
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 73.23532142857142,
            "p50": 65.0628,
            "p95": 106.2129
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4813,
              "llm_output_tokens": 307,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 461,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0005328119999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4813,
              "llm_output_tokens": 307,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 461,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0005328119999999999,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2448.3468,
            "p50": 2448.3468,
            "p95": 2448.3468
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 67475,
              "llm_output_tokens": 3551,
              "llm_cache_hit_tokens": 62464,
              "llm_cache_miss_tokens": 5011,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 30,
            "usage_responses": 30,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 20
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.006139284,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 67475,
              "llm_output_tokens": 3551,
              "llm_cache_hit_tokens": 62464,
              "llm_cache_miss_tokens": 5011,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.006139284,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 1576.71188,
            "p50": 1200.9401,
            "p95": 3429.1103
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 13592,
              "llm_output_tokens": 618,
              "llm_cache_hit_tokens": 12544,
              "llm_cache_miss_tokens": 1048,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.001131264,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 13592,
              "llm_output_tokens": 618,
              "llm_cache_hit_tokens": 12544,
              "llm_cache_miss_tokens": 1048,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.001131264,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1389.950875,
            "p50": 958.7827,
            "p95": 1998.8623
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9573,
              "llm_output_tokens": 273,
              "llm_cache_hit_tokens": 8448,
              "llm_cache_miss_tokens": 1125,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000715788,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9573,
              "llm_output_tokens": 273,
              "llm_cache_hit_tokens": 8448,
              "llm_cache_miss_tokens": 1125,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000715788,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 892.291125,
            "p50": 837.2198,
            "p95": 1121.8275
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    },
    "hint": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 99069,
          "llm_output_tokens": 4776,
          "llm_cache_hit_tokens": 89856,
          "llm_cache_miss_tokens": 9213,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 42,
        "usage_responses": 42,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "openai": 29,
          "unreported": 19
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 44783,
          "jev_output_tokens": 5811
        },
        "usage_responses": 48,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.010915122000000001,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.006,
          "cache_miss_input_per_million": 0.3,
          "output_per_million": 1.2,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 99069,
          "llm_output_tokens": 4776,
          "llm_cache_hit_tokens": 89856,
          "llm_cache_miss_tokens": 9213,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 44783,
          "jev_output_tokens": 5811
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 48,
        "llm_estimate": 0.009034236000000001,
        "jev_estimate": 0.0018808860000000002
      },
      "llm_attempts_complete": true,
      "turn_attempts": 48,
      "request_latency_all_ms": {
        "count": 48,
        "average": 1189.8274104166667,
        "p50": 1315.727,
        "p95": 3231.1362
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 24,
        "completion_rate": 1,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 1,
        "preview_observed": 19,
        "preview_correct": 19,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 5,
        "cancel_no_write_observed": 5,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 42,
        "telemetry_turns": 48,
        "all_task_latency": {
          "count": 24,
          "average_ms": 2525.486183333333,
          "p50_ms": 2216.7581,
          "p95_ms": 3901.1728
        },
        "successful_task_latency": {
          "count": 24,
          "average_ms": 2525.486183333333,
          "p50_ms": 2216.7581,
          "p95_ms": 3901.1728
        },
        "time_to_preview": {
          "count": 19,
          "average_ms": 2347.6230105263157,
          "p50_ms": 2090.8751,
          "p95_ms": 4904.3411
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-revised-hint",
        "jev_mode": "on",
        "model": "deepseek-flash",
        "source_git": "f2b62e5eab0e8db61065f2f45db589d382bd37ab",
        "binary_sha256": "4a14ba252dd9744d6ecdf74d8a2696e00ebdb916a4359b871ec08d019951914f",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 68,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000273264,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 68,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000222444,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1917.5024,
            "p50": 1917.5024,
            "p95": 1917.5024
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1996.2025,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 360,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 68,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000273264,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 68,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000222444,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1917.5024,
                "p50": 1917.5024,
                "p95": 1917.5024
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4901,
              "llm_output_tokens": 292,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 421,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000574896,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4901,
              "llm_output_tokens": 292,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 421,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00050358,
            "jev_estimate": 7.1316e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1598.5267000000001,
            "p50": 43.7375,
            "p95": 3153.3159
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3351.037,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3206.183,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 355,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 43.7375,
                "p50": 43.7375,
                "p95": 43.7375
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4901,
                  "llm_output_tokens": 292,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 421,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000574896,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4901,
                  "llm_output_tokens": 292,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 421,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00050358,
                "jev_estimate": 7.1316e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3153.3159,
                "p50": 3153.3159,
                "p95": 3153.3159
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4802,
              "llm_output_tokens": 177,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 450,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000445752,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4802,
              "llm_output_tokens": 177,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 450,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000373512,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1211.0044500000001,
            "p50": 64.5565,
            "p95": 2357.4524
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2551.8113,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2403.3846,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 352,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 64.5565,
                "p50": 64.5565,
                "p95": 64.5565
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4802,
                  "llm_output_tokens": 177,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 450,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000445752,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4802,
                  "llm_output_tokens": 177,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 450,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000373512,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2357.4524,
                "p50": 2357.4524,
                "p95": 2357.4524
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4627,
              "llm_output_tokens": 75,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 403,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00028756800000000004,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4627,
              "llm_output_tokens": 75,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 403,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000236244,
            "jev_estimate": 5.1324000000000005e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1720.3981,
            "p50": 1720.3981,
            "p95": 1720.3981
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1813.2396,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 371,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4627,
                  "llm_output_tokens": 75,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 403,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00028756800000000004,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4627,
                  "llm_output_tokens": 75,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 403,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000236244,
                "jev_estimate": 5.1324000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1720.3981,
                "p50": 1720.3981,
                "p95": 1720.3981
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 64,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022822800000000002,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 64,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000155988,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 768.45065,
            "p50": 41.9884,
            "p95": 1494.9129
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1686.1816,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1544.5704,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 350,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 41.9884,
                "p50": 41.9884,
                "p95": 41.9884
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022822800000000002,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000155988,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1494.9129,
                "p50": 1494.9129,
                "p95": 1494.9129
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7636,
              "llm_output_tokens": 589,
              "llm_cache_hit_tokens": 6912,
              "llm_cache_miss_tokens": 724,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.001088112,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7636,
              "llm_output_tokens": 589,
              "llm_cache_hit_tokens": 6912,
              "llm_cache_miss_tokens": 724,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000965472,
            "jev_estimate": 0.00012264
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1624.9323,
            "p50": 1581.2093,
            "p95": 3231.1362
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 5057.1471,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 4904.3411,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 345,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 62.4514,
                "p50": 62.4514,
                "p95": 62.4514
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4988,
                  "llm_output_tokens": 528,
                  "llm_cache_hit_tokens": 4608,
                  "llm_cache_miss_tokens": 380,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000825732,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4988,
                  "llm_output_tokens": 528,
                  "llm_cache_hit_tokens": 4608,
                  "llm_cache_miss_tokens": 380,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0007752480000000001,
                "jev_estimate": 5.0484e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3231.1362,
                "p50": 3231.1362,
                "p95": 3231.1362
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2648,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 344,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00026238,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2648,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 344,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000190224,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1581.2093,
                "p50": 1581.2093,
                "p95": 1581.2093
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 204,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00039686400000000003,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 204,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000324288,
            "jev_estimate": 7.2576e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 929.4259,
            "p50": 71.3761,
            "p95": 1787.4757
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2016.618,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1843.2896,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 341,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 71.3761,
                "p50": 71.3761,
                "p95": 71.3761
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 204,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00039686400000000003,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 204,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000324288,
                "jev_estimate": 7.2576e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1787.4757,
                "p50": 1787.4757,
                "p95": 1787.4757
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 56,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00021675599999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 56,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00014518799999999998,
            "jev_estimate": 7.1568e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 552.5319000000001,
            "p50": 40.7849,
            "p95": 1064.2789
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1231.7567,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1110.1779,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 307,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 40.7849,
                "p50": 40.7849,
                "p95": 40.7849
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00021675599999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00014518799999999998,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1064.2789,
                "p50": 1064.2789,
                "p95": 1064.2789
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 83,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00038328599999999993,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 83,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.00026127599999999996,
            "jev_estimate": 0.00012201
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 778.8274,
            "p50": 756.1131,
            "p95": 1484.4914
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2557.4832,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2338.3246,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 304,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 95.8777,
                "p50": 95.8777,
                "p95": 95.8777
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 26,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00015933,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 26,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00010888799999999999,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 756.1131,
                "p50": 756.1131,
                "p95": 756.1131
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022395599999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00015238799999999996,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1484.4914,
                "p50": 1484.4914,
                "p95": 1484.4914
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 65,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022866,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 65,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00015658799999999999,
            "jev_estimate": 7.2072e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 892.0496999999999,
            "p50": 105.7051,
            "p95": 1678.3943
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1918.4352,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1728.3867,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 300,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 105.7051,
                "p50": 105.7051,
                "p95": 105.7051
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 65,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022866,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 65,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00015658799999999999,
                "jev_estimate": 7.2072e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1678.3943,
                "p50": 1678.3943,
                "p95": 1678.3943
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4540,
              "llm_output_tokens": 411,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 444,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000773028,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4540,
              "llm_output_tokens": 411,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 444,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000650976,
            "jev_estimate": 0.000122052
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1207.2539666666667,
            "p50": 1315.727,
            "p95": 2184.2145
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3901.1728,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1445.4737,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 310,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 121.8204,
                "p50": 121.8204,
                "p95": 121.8204
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 354,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000554604,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 354,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000504288,
                "jev_estimate": 5.0316000000000004e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2184.2145,
                "p50": 2184.2145,
                "p95": 2184.2145
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000218424,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000146688,
                "jev_estimate": 7.1736e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1315.727,
                "p50": 1315.727,
                "p95": 1315.727
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 97,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000266598,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 97,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000194988,
            "jev_estimate": 7.161e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 813.7323,
            "p50": 50.045,
            "p95": 1577.4196
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1764.3311,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1621.267,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 320,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 50.045,
                "p50": 50.045,
                "p95": 50.045
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 97,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000266598,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 97,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000194988,
                "jev_estimate": 7.161e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1577.4196,
                "p50": 1577.4196,
                "p95": 1577.4196
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 100,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00027411600000000003,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 100,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00020128800000000001,
            "jev_estimate": 7.2828e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 719.04755,
            "p50": 66.5326,
            "p95": 1371.5625
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1588.0161,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1433.5321,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 370,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 66.5326,
                "p50": 66.5326,
                "p95": 66.5326
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 100,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00027411600000000003,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 100,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00020128800000000001,
                "jev_estimate": 7.2828e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1371.5625,
                "p50": 1371.5625,
                "p95": 1371.5625
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 215,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00041130599999999995,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 215,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00033868799999999997,
            "jev_estimate": 7.261800000000002e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1051.64905,
            "p50": 55.551,
            "p95": 2047.7471
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2216.7581,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2090.8751,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 322,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 55.551,
                "p50": 55.551,
                "p95": 55.551
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 215,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00041130599999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 215,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00033868799999999997,
                "jev_estimate": 7.261800000000002e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2047.7471,
                "p50": 2047.7471,
                "p95": 2047.7471
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4593,
              "llm_output_tokens": 164,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 369,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00045523199999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4593,
              "llm_output_tokens": 164,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 369,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000332844,
            "jev_estimate": 0.000122388
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 852.0998666666667,
            "p50": 1151.9413,
            "p95": 1334.339
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2734.9627,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2578.103,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 317,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 70.0193,
                "p50": 70.0193,
                "p95": 70.0193
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 98,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00024632999999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 98,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00019588799999999996,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1151.9413,
                "p50": 1151.9413,
                "p95": 1151.9413
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2325,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000208902,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2325,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000136956,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1334.339,
                "p50": 1334.339,
                "p95": 1334.339
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 98,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1818,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000280944,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 98,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1818,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000204588,
            "jev_estimate": 7.635600000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 906.2445,
            "p50": 81.2516,
            "p95": 1731.2374
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1964.7329,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1777.6481,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 326,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 81.2516,
                "p50": 81.2516,
                "p95": 81.2516
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 98,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1818,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000280944,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 98,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1818,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000204588,
                "jev_estimate": 7.635600000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1731.2374,
                "p50": 1731.2374,
                "p95": 1731.2374
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 107,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000279534,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 107,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000207588,
            "jev_estimate": 7.194599999999999e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 909.517,
            "p50": 85.5469,
            "p95": 1733.4871
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1990.8746,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1783.55,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 314,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 85.5469,
                "p50": 85.5469,
                "p95": 85.5469
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 107,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000279534,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 107,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000207588,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1733.4871,
                "p50": 1733.4871,
                "p95": 1733.4871
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4611,
              "llm_output_tokens": 71,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 387,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000277464,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4611,
              "llm_output_tokens": 71,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 387,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000226644,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1845.6941,
            "p50": 1845.6941,
            "p95": 1845.6941
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1927.2131,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 365,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4611,
                  "llm_output_tokens": 71,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 387,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000277464,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4611,
                  "llm_output_tokens": 71,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 387,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000226644,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1845.6941,
                "p50": 1845.6941,
                "p95": 1845.6941
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4712,
              "llm_output_tokens": 258,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 488,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0005327099999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4712,
              "llm_output_tokens": 258,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 488,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.0004813439999999999,
            "jev_estimate": 5.1366e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2613.4484,
            "p50": 2613.4484,
            "p95": 2613.4484
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2714.2854,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 367,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4712,
                  "llm_output_tokens": 258,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 488,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0005327099999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4712,
                  "llm_output_tokens": 258,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 488,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0004813439999999999,
                "jev_estimate": 5.1366e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2613.4484,
                "p50": 2613.4484,
                "p95": 2613.4484
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7256,
              "llm_output_tokens": 354,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 600,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000716892,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7256,
              "llm_output_tokens": 354,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 600,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000644736,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1691.29755,
            "p50": 42.1652,
            "p95": 3340.4299
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3504.9341,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3387.3316,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 334,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 42.1652,
                "p50": 42.1652,
                "p95": 42.1652
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7256,
                  "llm_output_tokens": 354,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 600,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000716892,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7256,
                  "llm_output_tokens": 354,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 600,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000644736,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3340.4299,
                "p50": 3340.4299,
                "p95": 3340.4299
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 306,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000518244,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 306,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000446088,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1160.4715,
            "p50": 62.9418,
            "p95": 2258.0012
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2464.4818,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2306.915,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 339,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 62.9418,
                "p50": 62.9418,
                "p95": 62.9418
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 306,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000518244,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 306,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000446088,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2258.0012,
                "p50": 2258.0012,
                "p95": 2258.0012
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7406,
              "llm_output_tokens": 349,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 750,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000806502,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7406,
              "llm_output_tokens": 349,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 750,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000683736,
            "jev_estimate": 0.000122766
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1193.1591666666668,
            "p50": 1147.0905,
            "p95": 2372.871
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3768.5073,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3611.6433,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 331,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 59.516,
                "p50": 59.516,
                "p95": 59.516
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4782,
                  "llm_output_tokens": 294,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 430,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000558522,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4782,
                  "llm_output_tokens": 294,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 430,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000507912,
                "jev_estimate": 5.0610000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2372.871,
                "p50": 2372.871,
                "p95": 2372.871
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2624,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 320,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00024798,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2624,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 320,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00017582400000000002,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1147.0905,
                "p50": 1147.0905,
                "p95": 1147.0905
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7392,
              "llm_output_tokens": 374,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 608,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000744228,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7392,
              "llm_output_tokens": 374,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 608,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000671904,
            "jev_estimate": 7.2324e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1759.1923000000002,
            "p50": 68.6006,
            "p95": 3449.784
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3657.4907,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3489.8404,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 327,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 68.6006,
                "p50": 68.6006,
                "p95": 68.6006
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7392,
                  "llm_output_tokens": 374,
                  "llm_cache_hit_tokens": 6784,
                  "llm_cache_miss_tokens": 608,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000744228,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7392,
                  "llm_output_tokens": 374,
                  "llm_cache_hit_tokens": 6784,
                  "llm_cache_miss_tokens": 608,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000671904,
                "jev_estimate": 7.2324e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3449.784,
                "p50": 3449.784,
                "p95": 3449.784
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4691,
              "llm_output_tokens": 199,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 467,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00045493799999999995,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4691,
              "llm_output_tokens": 199,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 467,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00040424399999999995,
            "jev_estimate": 5.0694e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2119.5725,
            "p50": 2119.5725,
            "p95": 2119.5725
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2233.9955,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 362,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4691,
                  "llm_output_tokens": 199,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 467,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00045493799999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4691,
                  "llm_output_tokens": 199,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 467,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00040424399999999995,
                "jev_estimate": 5.0694e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2119.5725,
                "p50": 2119.5725,
                "p95": 2119.5725
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 2525.4861833333334,
        "p50": 2216.7581,
        "p95": 3901.1728
      },
      "latency_successful_tasks_ms": {
        "count": 24,
        "average": 2525.4861833333334,
        "p50": 2216.7581,
        "p95": 3901.1728
      },
      "failure_details": [],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 5
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 5,
          "request_latency_all_ms": {
            "count": 5,
            "average": 43.7442,
            "p50": 42.1652,
            "p95": 50.045
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 76.55335714285714,
            "p50": 68.6006,
            "p95": 121.8204
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 354,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000554604,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 354,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000504288,
            "jev_estimate": 5.0316000000000004e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2184.2145,
            "p50": 2184.2145,
            "p95": 2184.2145
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 72609,
              "llm_output_tokens": 3237,
              "llm_cache_hit_tokens": 65920,
              "llm_cache_miss_tokens": 6689,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 31,
            "usage_responses": 31,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 20
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 31923,
              "jev_output_tokens": 4051
            },
            "usage_responses": 35,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.007627385999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 72609,
              "llm_output_tokens": 3237,
              "llm_cache_hit_tokens": 65920,
              "llm_cache_miss_tokens": 6689,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 31923,
              "jev_output_tokens": 4051
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 35,
            "llm_estimate": 0.006286619999999999,
            "jev_estimate": 0.0013407660000000002
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 2028.89207,
            "p50": 1787.4757,
            "p95": 3340.4299
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 14304,
              "llm_output_tokens": 946,
              "llm_cache_hit_tokens": 13056,
              "llm_cache_miss_tokens": 1248,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.001789914,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 14304,
              "llm_output_tokens": 946,
              "llm_cache_hit_tokens": 13056,
              "llm_cache_miss_tokens": 1248,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 4,
            "llm_estimate": 0.001587936,
            "jev_estimate": 0.000201978
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1878.0154,
            "p50": 1151.9413,
            "p95": 3231.1362
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9884,
              "llm_output_tokens": 239,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1052,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "usage_responses": 8,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0009432180000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9884,
              "llm_output_tokens": 239,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1052,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 8,
            "llm_estimate": 0.0006553920000000001,
            "jev_estimate": 0.00028782600000000003
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1386.78255,
            "p50": 1334.339,
            "p95": 1581.2093
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    },
    "fast": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 89333,
          "llm_output_tokens": 4104,
          "llm_cache_hit_tokens": 80768,
          "llm_cache_miss_tokens": 8565,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 38,
        "usage_responses": 38,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "unreported": 21,
          "openai": 27
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 44783,
          "jev_output_tokens": 5811
        },
        "usage_responses": 48,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.009859794,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.006,
          "cache_miss_input_per_million": 0.3,
          "output_per_million": 1.2,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 89333,
          "llm_output_tokens": 4104,
          "llm_cache_hit_tokens": 80768,
          "llm_cache_miss_tokens": 8565,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 44783,
          "jev_output_tokens": 5811
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 48,
        "llm_estimate": 0.007978908,
        "jev_estimate": 0.0018808860000000002
      },
      "llm_attempts_complete": true,
      "turn_attempts": 48,
      "request_latency_all_ms": {
        "count": 48,
        "average": 1158.8048770833334,
        "p50": 1144.2976,
        "p95": 3328.2837
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 24,
        "completion_rate": 1,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 0,
        "preview_observed": 19,
        "preview_correct": 19,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 5,
        "cancel_no_write_observed": 5,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 38,
        "telemetry_turns": 48,
        "all_task_latency": {
          "count": 24,
          "average_ms": 2457.9909500000003,
          "p50_ms": 2056.0216,
          "p95_ms": 4401.9705
        },
        "successful_task_latency": {
          "count": 24,
          "average_ms": 2457.9909500000003,
          "p50_ms": 2056.0216,
          "p95_ms": 4401.9705
        },
        "time_to_preview": {
          "count": 19,
          "average_ms": 2425.741736842105,
          "p50_ms": 1914.6695,
          "p95_ms": 5869.5316
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-revised-fast",
        "jev_mode": "on",
        "model": "deepseek-flash",
        "source_git": "f2b62e5eab0e8db61065f2f45db589d382bd37ab",
        "binary_sha256": "4a14ba252dd9744d6ecdf74d8a2696e00ebdb916a4359b871ec08d019951914f",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 5.082e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.0,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 342.291,
            "p50": 342.291,
            "p95": 342.291
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 418.3411,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [
            "balance-read:0"
          ],
          "fast_selected": true,
          "tenant_id": 361,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 5.082e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 342.291,
                "p50": 342.291,
                "p95": 342.291
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4759,
              "llm_output_tokens": 198,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 407,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000457128,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4759,
              "llm_output_tokens": 198,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 407,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000385812,
            "jev_estimate": 7.1316e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1203.8340500000002,
            "p50": 40.9142,
            "p95": 2366.7539
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2550.9337,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 2414.2782,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 359,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 40.9142,
                "p50": 40.9142,
                "p95": 40.9142
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4759,
                  "llm_output_tokens": 198,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 407,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000457128,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4759,
                  "llm_output_tokens": 198,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 407,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000385812,
                "jev_estimate": 7.1316e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2366.7539,
                "p50": 2366.7539,
                "p95": 2366.7539
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2277,
              "llm_output_tokens": 201,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 229,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000394428,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2277,
              "llm_output_tokens": 201,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 229,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000322188,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1099.2491,
            "p50": 65.8901,
            "p95": 2132.6081
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2331.802,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2183.439,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 356,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 65.8901,
                "p50": 65.8901,
                "p95": 65.8901
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2277,
                  "llm_output_tokens": 201,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 229,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000394428,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2277,
                  "llm_output_tokens": 201,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 229,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000322188,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2132.6081,
                "p50": 2132.6081,
                "p95": 2132.6081
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4618,
              "llm_output_tokens": 78,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 394,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000288468,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4618,
              "llm_output_tokens": 78,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 394,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00023714399999999998,
            "jev_estimate": 5.1324000000000005e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2074.3296,
            "p50": 2074.3296,
            "p95": 2074.3296
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2147.3668,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 369,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4618,
                  "llm_output_tokens": 78,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 394,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000288468,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4618,
                  "llm_output_tokens": 78,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 394,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00023714399999999998,
                "jev_estimate": 5.1324000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2074.3296,
                "p50": 2074.3296,
                "p95": 2074.3296
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000295428,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00022318799999999998,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 764.20835,
            "p50": 41.9755,
            "p95": 1486.4412
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1680.4397,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1538.1722,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 354,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 41.9755,
                "p50": 41.9755,
                "p95": 41.9755
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000295428,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00022318799999999998,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1486.4412,
                "p50": 1486.4412,
                "p95": 1486.4412
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7577,
              "llm_output_tokens": 548,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 793,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.001058844,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7577,
              "llm_output_tokens": 548,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 793,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.0009362039999999999,
            "jev_estimate": 0.00012264
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1945.1686333333334,
            "p50": 1892.2113,
            "p95": 3881.6206
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 6030.7989,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 5869.5316,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 347,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.674,
                "p50": 61.674,
                "p95": 61.674
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4937,
                  "llm_output_tokens": 490,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 457,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0008024639999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4937,
                  "llm_output_tokens": 490,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 457,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00075198,
                "jev_estimate": 5.0484e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3881.6206,
                "p50": 3881.6206,
                "p95": 3881.6206
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2640,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00025637999999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2640,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00018422399999999998,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1892.2113,
                "p50": 1892.2113,
                "p95": 1892.2113
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 198,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00038966399999999996,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 198,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000317088,
            "jev_estimate": 7.2576e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 963.6143000000001,
            "p50": 63.2352,
            "p95": 1863.9934
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2083.3898,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1914.6695,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 344,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 63.2352,
                "p50": 63.2352,
                "p95": 63.2352
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 198,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00038966399999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 198,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000317088,
                "jev_estimate": 7.2576e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1863.9934,
                "p50": 1863.9934,
                "p95": 1863.9934
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 57,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000217956,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 57,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00014638799999999998,
            "jev_estimate": 7.1568e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 596.2157000000001,
            "p50": 48.1338,
            "p95": 1144.2976
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1325.5018,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1189.0221,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 309,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 48.1338,
                "p50": 48.1338,
                "p95": 48.1338
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000217956,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00014638799999999998,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1144.2976,
                "p50": 1144.2976,
                "p95": 1144.2976
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4562,
              "llm_output_tokens": 100,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 466,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000406386,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4562,
              "llm_output_tokens": 100,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 466,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000284376,
            "jev_estimate": 0.00012201
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 828.4514333333334,
            "p50": 944.6121,
            "p95": 1446.3655
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2671.832,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2490.0056,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 305,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 94.3767,
                "p50": 94.3767,
                "p95": 94.3767
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 42,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00017852999999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 42,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000128088,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 944.6121,
                "p50": 944.6121,
                "p95": 944.6121
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2296,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 248,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022785599999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2296,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 248,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00015628799999999998,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1446.3655,
                "p50": 1446.3655,
                "p95": 1446.3655
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 66,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022986000000000003,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 66,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00015778800000000001,
            "jev_estimate": 7.2072e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 900.9319,
            "p50": 101.2093,
            "p95": 1700.6545
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1953.7564,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1754.741,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 301,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 101.2093,
                "p50": 101.2093,
                "p95": 101.2093
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022986000000000003,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00015778800000000001,
                "jev_estimate": 7.2072e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1700.6545,
                "p50": 1700.6545,
                "p95": 1700.6545
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7043,
              "llm_output_tokens": 330,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 643,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0007493519999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7043,
              "llm_output_tokens": 330,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 643,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.0006272999999999999,
            "jev_estimate": 0.000122052
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1404.2126,
            "p50": 1436.959,
            "p95": 2667.5327
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 4401.9705,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1490.4749,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 311,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 108.1461,
                "p50": 108.1461,
                "p95": 108.1461
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4775,
                  "llm_output_tokens": 264,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 423,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000520128,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4775,
                  "llm_output_tokens": 264,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 423,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000469812,
                "jev_estimate": 5.0316000000000004e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2667.5327,
                "p50": 2667.5327,
                "p95": 2667.5327
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000229224,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 66,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000157488,
                "jev_estimate": 7.1736e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1436.959,
                "p50": 1436.959,
                "p95": 1436.959
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 126,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000301398,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 126,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00022978799999999998,
            "jev_estimate": 7.161e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 813.2537,
            "p50": 45.7002,
            "p95": 1580.8072
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1756.4832,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1623.4421,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 321,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 45.7002,
                "p50": 45.7002,
                "p95": 45.7002
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 126,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000301398,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 126,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00022978799999999998,
                "jev_estimate": 7.161e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1580.8072,
                "p50": 1580.8072,
                "p95": 1580.8072
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 138,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00031971599999999995,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 138,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00024688799999999996,
            "jev_estimate": 7.2828e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 919.85435,
            "p50": 63.9701,
            "p95": 1775.7386
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1970.1126,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1818.5431,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 368,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 63.9701,
                "p50": 63.9701,
                "p95": 63.9701
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 138,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00031971599999999995,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 138,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00024688799999999996,
                "jev_estimate": 7.2828e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1775.7386,
                "p50": 1775.7386,
                "p95": 1775.7386
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 352,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0005757059999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 352,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000503088,
            "jev_estimate": 7.261800000000002e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1301.1817,
            "p50": 92.049,
            "p95": 2510.3144
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2784.3477,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2581.9065,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 324,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 92.049,
                "p50": 92.049,
                "p95": 92.049
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 352,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0005757059999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 352,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000503088,
                "jev_estimate": 7.261800000000002e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2510.3144,
                "p50": 2510.3144,
                "p95": 2510.3144
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4616,
              "llm_output_tokens": 211,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 392,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000518532,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4616,
              "llm_output_tokens": 211,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 392,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000396144,
            "jev_estimate": 0.000122388
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1143.1805666666667,
            "p50": 1644.5821,
            "p95": 1715.0108
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3608.4508,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3444.9142,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 318,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.9488,
                "p50": 69.9488,
                "p95": 69.9488
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 138,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00029433,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 138,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00024388799999999997,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1715.0108,
                "p50": 1715.0108,
                "p95": 1715.0108
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2348,
                  "llm_output_tokens": 73,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 172,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000224202,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2348,
                  "llm_output_tokens": 73,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 172,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000152256,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1644.5821,
                "p50": 1644.5821,
                "p95": 1644.5821
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2299,
              "llm_output_tokens": 106,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 251,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1818,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000291144,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2299,
              "llm_output_tokens": 106,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 251,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1818,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000214788,
            "jev_estimate": 7.635600000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 783.05025,
            "p50": 71.1002,
            "p95": 1495.0003
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1697.6347,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1547.4454,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 328,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 71.1002,
                "p50": 71.1002,
                "p95": 71.1002
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2299,
                  "llm_output_tokens": 106,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 251,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1818,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000291144,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2299,
                  "llm_output_tokens": 106,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 251,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1818,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000214788,
                "jev_estimate": 7.635600000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1495.0003,
                "p50": 1495.0003,
                "p95": 1495.0003
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 130,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000307134,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 130,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000235188,
            "jev_estimate": 7.194599999999999e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 880.39375,
            "p50": 71.3374,
            "p95": 1689.4501
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1924.9608,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1742.55,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 315,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 71.3374,
                "p50": 71.3374,
                "p95": 71.3374
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 130,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000307134,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 130,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000235188,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1689.4501,
                "p50": 1689.4501,
                "p95": 1689.4501
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4614,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 390,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000268764,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4614,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 390,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000217944,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1954.6751,
            "p50": 1954.6751,
            "p95": 1954.6751
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2038.6242,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 364,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000268764,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000217944,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1954.6751,
                "p50": 1954.6751,
                "p95": 1954.6751
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4705,
              "llm_output_tokens": 197,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 481,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00045741,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4705,
              "llm_output_tokens": 197,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 481,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000406044,
            "jev_estimate": 5.1366e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1966.1679,
            "p50": 1966.1679,
            "p95": 1966.1679
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2056.0216,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 366,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4705,
                  "llm_output_tokens": 197,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 481,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00045741,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4705,
                  "llm_output_tokens": 197,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 481,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000406044,
                "jev_estimate": 5.1366e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1966.1679,
                "p50": 1966.1679,
                "p95": 1966.1679
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7193,
              "llm_output_tokens": 168,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 665,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000512424,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7193,
              "llm_output_tokens": 168,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 665,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000440268,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1688.49905,
            "p50": 48.7144,
            "p95": 3328.2837
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3500.9792,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3369.7889,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 337,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 48.7144,
                "p50": 48.7144,
                "p95": 48.7144
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7193,
                  "llm_output_tokens": 168,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 665,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000512424,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7193,
                  "llm_output_tokens": 168,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 665,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000440268,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3328.2837,
                "p50": 3328.2837,
                "p95": 3328.2837
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 111,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00028424399999999996,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 111,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00021208799999999995,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 767.81595,
            "p50": 60.3949,
            "p95": 1475.237
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1678.3242,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1525.7582,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 340,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 60.3949,
                "p50": 60.3949,
                "p95": 60.3949
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 111,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00028424399999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 111,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00021208799999999995,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1475.237,
                "p50": 1475.237,
                "p95": 1475.237
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7411,
              "llm_output_tokens": 345,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 755,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000803202,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7411,
              "llm_output_tokens": 345,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 755,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000680436,
            "jev_estimate": 0.000122766
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1256.5899666666667,
            "p50": 1101.7426,
            "p95": 2598.7257
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3960.1524,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3791.0703,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 333,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.3016,
                "p50": 69.3016,
                "p95": 69.3016
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4784,
                  "llm_output_tokens": 290,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 432,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000554322,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4784,
                  "llm_output_tokens": 290,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 432,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000503712,
                "jev_estimate": 5.0610000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2598.7257,
                "p50": 2598.7257,
                "p95": 2598.7257
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2627,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 323,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00024888,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2627,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 323,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00017672399999999998,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1101.7426,
                "p50": 1101.7426,
                "p95": 1101.7426
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7216,
              "llm_output_tokens": 261,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 688,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0006310920000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7216,
              "llm_output_tokens": 261,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 688,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.0005587680000000001,
            "jev_estimate": 7.2324e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1906.4605000000001,
            "p50": 62.1572,
            "p95": 3750.7638
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3952.8596,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3799.3402,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 330,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 62.1572,
                "p50": 62.1572,
                "p95": 62.1572
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7216,
                  "llm_output_tokens": 261,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 688,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0006310920000000001,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7216,
                  "llm_output_tokens": 261,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 688,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.0005587680000000001,
                "jev_estimate": 7.2324e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3750.7638,
                "p50": 3750.7638,
                "p95": 3750.7638
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 5.0694e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.0,
            "jev_estimate": 5.0694e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 375.2356,
            "p50": 375.2356,
            "p95": 375.2356
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 466.6991,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [
            "subscription-read:0"
          ],
          "fast_selected": true,
          "tenant_id": 363,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 5.0694e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.006,
                  "cache_miss_input_per_million": 0.3,
                  "output_per_million": 1.2,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0,
                "jev_estimate": 5.0694e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 375.2356,
                "p50": 375.2356,
                "p95": 375.2356
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 2457.99095,
        "p50": 2056.0216,
        "p95": 4401.9705
      },
      "latency_successful_tasks_ms": {
        "count": 24,
        "average": 2457.99095,
        "p50": 2056.0216,
        "p95": 4401.9705
      },
      "failure_details": [],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 5
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 5,
          "request_latency_all_ms": {
            "count": 5,
            "average": 45.08762,
            "p50": 45.7002,
            "p95": 48.7144
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 75.34218571428572,
            "p50": 69.3016,
            "p95": 108.1461
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4775,
              "llm_output_tokens": 264,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 423,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000520128,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4775,
              "llm_output_tokens": 264,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 423,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000469812,
            "jev_estimate": 5.0316000000000004e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2667.5327,
            "p50": 2667.5327,
            "p95": 2667.5327
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 60392,
              "llm_output_tokens": 2636,
              "llm_cache_hit_tokens": 54656,
              "llm_cache_miss_tokens": 5736,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 26,
            "usage_responses": 26,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 2,
              "openai": 18
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 31923,
              "jev_output_tokens": 4051
            },
            "usage_responses": 35,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.006552702,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 60392,
              "llm_output_tokens": 2636,
              "llm_cache_hit_tokens": 54656,
              "llm_cache_miss_tokens": 5736,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 31923,
              "jev_output_tokens": 4051
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 35,
            "llm_estimate": 0.0052119359999999995,
            "jev_estimate": 0.0013407660000000002
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 1822.5001,
            "p50": 1700.6545,
            "p95": 3328.2837
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 14255,
              "llm_output_tokens": 960,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1327,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0018296459999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 14255,
              "llm_output_tokens": 960,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1327,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 4,
            "llm_estimate": 0.0016276679999999999,
            "jev_estimate": 0.000201978
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 2284.9923,
            "p50": 1715.0108,
            "p95": 3881.6206
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9911,
              "llm_output_tokens": 244,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1079,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "usage_responses": 8,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000957318,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.006,
              "cache_miss_input_per_million": 0.3,
              "output_per_million": 1.2,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9911,
              "llm_output_tokens": 244,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1079,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 8,
            "llm_estimate": 0.0006694919999999999,
            "jev_estimate": 0.00028782600000000003
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1521.225375,
            "p50": 1446.3655,
            "p95": 1892.2113
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    }
  },
  "paired_latency": {
    "all_three_success": {
      "ids": [
        "balance-read",
        "cancel-abort",
        "cancel-subscription",
        "cancelled-read",
        "change-cancel",
        "change-missing",
        "change-ready",
        "recharge-cancel",
        "recharge-missing",
        "recharge-ready",
        "recharge-repeat",
        "refund-cancel",
        "refund-capped",
        "refund-composite",
        "refund-missing",
        "refund-order",
        "refund-ready",
        "satisfied-balance",
        "satisfied-subscription",
        "subscribe-cancel",
        "subscribe-flagship",
        "subscribe-missing",
        "subscribe-ready",
        "subscription-read"
      ],
      "count": 24,
      "runs": {
        "baseline": {
          "count": 24,
          "average": 1989.9916875,
          "p50": 1570.5655,
          "p95": 3594.5247
        },
        "hint": {
          "count": 24,
          "average": 2525.4861833333334,
          "p50": 2216.7581,
          "p95": 3901.1728
        },
        "fast": {
          "count": 24,
          "average": 2457.99095,
          "p50": 2056.0216,
          "p95": 4401.9705
        }
      },
      "baseline_minus_fast_ms": {
        "count": 24,
        "average": -467.9992625,
        "p50": -579.5056,
        "p95": 1037.1266999999998
      },
      "hint_minus_fast_ms": {
        "count": 24,
        "average": 67.49523333333336,
        "p50": -66.77179999999998,
        "p95": 1577.8614000000002
      }
    },
    "fast_selected_all_three_success": {
      "ids": [
        "balance-read",
        "subscription-read"
      ],
      "count": 2,
      "runs": {
        "baseline": {
          "count": 2,
          "average": 1626.41395,
          "p50": 1455.4678,
          "p95": 1797.3601
        },
        "hint": {
          "count": 2,
          "average": 2115.099,
          "p50": 1996.2025,
          "p95": 2233.9955
        },
        "fast": {
          "count": 2,
          "average": 442.52009999999996,
          "p50": 418.3411,
          "p95": 466.6991
        }
      },
      "baseline_minus_fast_ms": {
        "count": 2,
        "average": 1183.89385,
        "p50": 1037.1266999999998,
        "p95": 1330.661
      },
      "hint_minus_fast_ms": {
        "count": 2,
        "average": 1672.5789,
        "p50": 1577.8614000000002,
        "p95": 1767.2964
      }
    }
  },
  "fast_selected_task_comparison": {
    "ids": [
      "balance-read",
      "subscription-read"
    ],
    "count": 2,
    "runs": {
      "baseline": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 8988,
            "llm_output_tokens": 228,
            "llm_cache_hit_tokens": 8320,
            "llm_cache_miss_tokens": 668,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 4,
          "usage_responses": 4,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.00052392,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 8988,
            "llm_output_tokens": 228,
            "llm_cache_hit_tokens": 8320,
            "llm_cache_miss_tokens": 668,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 0,
          "llm_estimate": 0.00052392,
          "jev_estimate": 0.0
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 1536.4872,
          "p50": 1368.7085,
          "p95": 1704.2659
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "hint": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 9300,
            "llm_output_tokens": 267,
            "llm_cache_hit_tokens": 8448,
            "llm_cache_miss_tokens": 852,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 4,
          "usage_responses": 4,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "usage_responses": 2,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.0007282020000000001,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 9300,
            "llm_output_tokens": 267,
            "llm_cache_hit_tokens": 8448,
            "llm_cache_miss_tokens": 852,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 2,
          "llm_estimate": 0.000626688,
          "jev_estimate": 0.000101514
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 2018.5374500000003,
          "p50": 1917.5024,
          "p95": 2119.5725
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "fast": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 0,
            "llm_output_tokens": 0,
            "llm_cache_hit_tokens": 0,
            "llm_cache_miss_tokens": 0,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 0,
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "unreported": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "usage_responses": 2,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.000101514,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 0,
            "llm_output_tokens": 0,
            "llm_cache_hit_tokens": 0,
            "llm_cache_miss_tokens": 0,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 2,
          "llm_estimate": 0.0,
          "jev_estimate": 0.000101514
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 358.76329999999996,
          "p50": 342.291,
          "p95": 375.2356
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      }
    },
    "baseline_minus_fast_llm_attempts": 4,
    "baseline_minus_fast_estimated_cost": 0.00042240599999999995,
    "baseline_minus_fast_tokens": {
      "llm_input_tokens": 8988,
      "llm_output_tokens": 228
    },
    "hint_minus_fast_llm_attempts": 4,
    "hint_minus_fast_estimated_cost": 0.000626688,
    "hint_minus_fast_tokens": {
      "llm_input_tokens": 9300,
      "llm_output_tokens": 267
    }
  },
  "non_fast_selected_task_comparison": {
    "ids": [
      "cancel-abort",
      "cancel-subscription",
      "cancelled-read",
      "change-cancel",
      "change-missing",
      "change-ready",
      "recharge-cancel",
      "recharge-missing",
      "recharge-ready",
      "recharge-repeat",
      "refund-cancel",
      "refund-capped",
      "refund-composite",
      "refund-missing",
      "refund-order",
      "refund-ready",
      "satisfied-balance",
      "satisfied-subscription",
      "subscribe-cancel",
      "subscribe-flagship",
      "subscribe-missing",
      "subscribe-ready"
    ],
    "count": 22,
    "runs": {
      "baseline": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 86465,
            "llm_output_tokens": 4521,
            "llm_cache_hit_tokens": 79488,
            "llm_cache_miss_tokens": 6977,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 38,
          "usage_responses": 38,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 19
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.007995227999999998,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 86465,
            "llm_output_tokens": 4521,
            "llm_cache_hit_tokens": 79488,
            "llm_cache_miss_tokens": 6977,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 0,
          "llm_estimate": 0.007995227999999998,
          "jev_estimate": 0.0
        },
        "llm_attempts_complete": true,
        "turn_attempts": 46,
        "request_latency_all_ms": {
          "count": 46,
          "average": 897.7686108695652,
          "p50": 770.1567,
          "p95": 3101.9249
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "hint": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 89769,
            "llm_output_tokens": 4509,
            "llm_cache_hit_tokens": 81408,
            "llm_cache_miss_tokens": 8361,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 38,
          "usage_responses": 38,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 19
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 42366,
            "jev_output_tokens": 5438
          },
          "usage_responses": 46,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.010186919999999999,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 89769,
            "llm_output_tokens": 4509,
            "llm_cache_hit_tokens": 81408,
            "llm_cache_miss_tokens": 8361,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 42366,
            "jev_output_tokens": 5438
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 46,
          "llm_estimate": 0.008407547999999999,
          "jev_estimate": 0.001779372
        },
        "llm_attempts_complete": true,
        "turn_attempts": 46,
        "request_latency_all_ms": {
          "count": 46,
          "average": 1153.796539130435,
          "p50": 1151.9413,
          "p95": 3231.1362
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "fast": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 89333,
            "llm_output_tokens": 4104,
            "llm_cache_hit_tokens": 80768,
            "llm_cache_miss_tokens": 8565,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 38,
          "usage_responses": 38,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 19
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 42366,
            "jev_output_tokens": 5438
          },
          "usage_responses": 46,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.00975828,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.006,
            "cache_miss_input_per_million": 0.3,
            "output_per_million": 1.2,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 89333,
            "llm_output_tokens": 4104,
            "llm_cache_hit_tokens": 80768,
            "llm_cache_miss_tokens": 8565,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 42366,
            "jev_output_tokens": 5438
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 46,
          "llm_estimate": 0.007978908,
          "jev_estimate": 0.001779372
        },
        "llm_attempts_complete": true,
        "turn_attempts": 46,
        "request_latency_all_ms": {
          "count": 46,
          "average": 1193.589293478261,
          "p50": 1436.959,
          "p95": 3328.2837
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      }
    },
    "baseline_minus_fast_llm_attempts": 0,
    "baseline_minus_fast_estimated_cost": -0.001763052000000001,
    "baseline_minus_fast_tokens": {
      "llm_input_tokens": -2868,
      "llm_output_tokens": 417
    },
    "hint_minus_fast_llm_attempts": 0,
    "hint_minus_fast_estimated_cost": 0.00042863999999999923,
    "hint_minus_fast_tokens": {
      "llm_input_tokens": 436,
      "llm_output_tokens": 405
    },
    "interpretation": "Differences on tasks without a selected JEV fast path are not attributable to JEV fast-path execution; confirmation/cancellation guards and ordinary model variation must be examined separately."
  },
  "fast_selection_unknown_task_ids": [],
  "matched_quality": {
    "baseline_to_fast": {
      "new_failure_ids": [],
      "recovered_failure_ids": []
    },
    "hint_to_fast": {
      "new_failure_ids": [],
      "recovered_failure_ids": []
    }
  },
  "limitations": [
    "Original task success, clarification and safety rubric retained without rescoring. Necessary followups are not errors.",
    "Redundant clarification is a heuristic candidate for manual review, not a proven error.",
    "Task duration includes final state verification but excludes fixture setup; synthetic followups have no user think time.",
    "All turn attempts, including failed responses and selected tool errors, remain in usage and cost denominators.",
    "Raw body telemetry is authoritative; missing or malformed raw telemetry stays unavailable, not zero.",
    "Same-task subsets may contain different turn sequences; they measure complete tasks, not a fabricated one-to-one turn match.",
    "Selected-task savings include the whole task and do not independently isolate a causal JEV effect.",
    "Independent fixture tenant IDs are checked across every task and arm; setup failures lacking an ID remain explicit.",
    "Repeated runs remain subject to upstream load and model variability."
  ],
  "sources": {
    "baseline": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\revised-tasks-nojev\\tasks.json",
      "sha256": "11014614852c47127654265e568685bcab6eacad1d5f4bb23269b6c3c1e38c41"
    },
    "hint": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\revised-tasks-hint\\tasks.json",
      "sha256": "e6c9bce436710eab286e4d14f7c3f412ccbd9138dea50c13c22f5f6db03e2e42"
    },
    "fast": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\revised-tasks-fast\\tasks.json",
      "sha256": "b870dbdbdbd4ea7ccc573bde09995d0250f05424c1e93dee342215d2d9f77ec2"
    }
  }
}
```
