# Multi-turn task efficiency comparison

Original completion and clarification rubric retained. All failures and usage completeness remain visible.

```json
{
  "schema": "taskbench.efficiency.v1",
  "dataset_sha256": "ea10920183f5c9c46afe9d6eaaadd2a15e1cbcdcebffe79a7ef9ee8ed637b1d9",
  "actual_cases_sha256": "da1b4b09e83f8acfbc328cf322314028ea374b6d1ec742cd1c692a7c85868017",
  "actual_cases": [
    {
      "id": "balance-read",
      "category": "read",
      "message": "我的账户现在还有多少余额？",
      "tool": "get_balance",
      "initial_subscription": false,
      "cancel": false,
      "read": true
    },
    {
      "id": "cancel-abort",
      "category": "cancel_subscription",
      "message": "退订当前套餐",
      "tool": "cancel_subscription",
      "initial_subscription": true,
      "cancel": true,
      "read": false
    },
    {
      "id": "cancel-subscription",
      "category": "cancel_subscription",
      "message": "退订我的定期订阅，停止下期自动续费",
      "tool": "cancel_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "cancelled-read",
      "category": "already_satisfied",
      "message": "只查询我现在还有没有生效中的定期订阅，不要重新订购",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "initially_cancelled": true,
      "cancel": false,
      "read": true
    },
    {
      "id": "change-cancel",
      "category": "change",
      "message": "把套餐改成月度·旗舰",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": true,
      "read": false
    },
    {
      "id": "change-missing",
      "category": "change",
      "message": "我要改套餐",
      "followup": "改成月度·旗舰套餐",
      "missing_slot": "plan",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "change-ready",
      "category": "change",
      "message": "把我当前的套餐改成月度·旗舰",
      "tool": "change_plan",
      "plan": "flagship",
      "initial_subscription": true,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-cancel",
      "category": "recharge",
      "message": "充值100元",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "recharge-missing",
      "category": "recharge",
      "message": "我要充值",
      "followup": "充值100元",
      "missing_slot": "amount",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-ready",
      "category": "recharge",
      "message": "给我的账户充值100元",
      "tool": "recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "recharge-repeat",
      "category": "recharge",
      "message": "帮我充200元",
      "tool": "recharge",
      "amount_money": 200,
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "duplicate_confirm": true
    },
    {
      "id": "refund-cancel",
      "category": "refund",
      "message": "退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "refund-capped",
      "category": "refund",
      "message": "按金额退款6000元，最多退到当前余额",
      "tool": "refund_recharge",
      "amount_money": 6000,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "refund-composite",
      "category": "refund",
      "message": "先查一下余额，然后帮我退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "require_balance_answer": true
    },
    {
      "id": "refund-missing",
      "category": "refund",
      "message": "我要退款",
      "followup": "按金额退款100元",
      "missing_slot": "amount",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "refund-order",
      "category": "refund",
      "message": "退掉已支付的充值订单{order_no}",
      "tool": "refund_recharge",
      "initial_subscription": false,
      "cancel": false,
      "read": false,
      "order_refund": true
    },
    {
      "id": "refund-ready",
      "category": "refund",
      "message": "请给我退款100元",
      "tool": "refund_recharge",
      "amount_money": 100,
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "satisfied-balance",
      "category": "already_satisfied",
      "message": "只查询余额，不充值也不退款",
      "tool": "get_balance",
      "initial_subscription": false,
      "cancel": false,
      "read": true
    },
    {
      "id": "satisfied-subscription",
      "category": "already_satisfied",
      "message": "我已经有月度·标准套餐，请查看当前订阅，不要重复订购",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": true
    },
    {
      "id": "subscribe-cancel",
      "category": "subscribe",
      "message": "订购月度·标准套餐",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": true,
      "read": false
    },
    {
      "id": "subscribe-flagship",
      "category": "subscribe",
      "message": "开通月度·旗舰订阅",
      "tool": "subscribe_plan",
      "plan": "flagship",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscribe-missing",
      "category": "subscribe",
      "message": "我要订购一个套餐",
      "followup": "订购月度·标准套餐",
      "missing_slot": "plan",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscribe-ready",
      "category": "subscribe",
      "message": "给我订购月度·标准套餐",
      "tool": "subscribe_plan",
      "plan": "standard",
      "initial_subscription": false,
      "cancel": false,
      "read": false
    },
    {
      "id": "subscription-read",
      "category": "read",
      "message": "查看我当前的订阅套餐",
      "tool": "get_my_subscription",
      "initial_subscription": true,
      "cancel": false,
      "read": true
    }
  ],
  "task_count": 24,
  "runs": {
    "baseline": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 98268,
          "llm_output_tokens": 4755,
          "llm_cache_hit_tokens": 90496,
          "llm_cache_miss_tokens": 7772,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 43,
        "usage_responses": 43,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "openai": 29,
          "unreported": 18
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 0,
          "jev_output_tokens": 0
        },
        "usage_responses": 0,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.004290288000000001,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.003,
          "cache_miss_input_per_million": 0.15,
          "output_per_million": 0.6,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 98268,
          "llm_output_tokens": 4755,
          "llm_cache_hit_tokens": 90496,
          "llm_cache_miss_tokens": 7772,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 0,
          "jev_output_tokens": 0
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 0,
        "llm_estimate": 0.004290288000000001,
        "jev_estimate": 0.0
      },
      "llm_attempts_complete": true,
      "turn_attempts": 47,
      "request_latency_all_ms": {
        "count": 47,
        "average": 977.4359510638297,
        "p50": 849.7803,
        "p95": 2950.5603
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 23,
        "completion_rate": 0.9583333333333334,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 3,
            "completion_rate": 0.75
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 3,
        "preview_observed": 18,
        "preview_correct": 18,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 4,
        "cancel_no_write_observed": 4,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 43,
        "telemetry_turns": 47,
        "all_task_latency": {
          "count": 24,
          "average_ms": 2044.8821249999994,
          "p50_ms": 1757.7827,
          "p95_ms": 3662.9065
        },
        "successful_task_latency": {
          "count": 23,
          "average_ms": 1984.205213043478,
          "p50_ms": 1757.7827,
          "p95_ms": 3662.9065
        },
        "time_to_preview": {
          "count": 18,
          "average_ms": 1731.8936222222221,
          "p50_ms": 1213.9097,
          "p95_ms": 3505.3004
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-nojev",
        "jev_mode": "off",
        "model": "deepseek-flash",
        "source_git": "f83b6498e9a9c4faf3329486aae4ca4cd85ee22a",
        "binary_sha256": "64c67789ab95ef3d2a23f3a709b7e6c7a9e819ba98615bf395bd821bc85f9f2e",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4449,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 353,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000101238,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4449,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 353,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000101238,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1658.6089,
            "p50": 1658.6089,
            "p95": 1658.6089
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1757.7827,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 253,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4449,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 353,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000101238,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4449,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 353,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000101238,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1658.6089,
                "p50": 1658.6089,
                "p95": 1658.6089
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4531,
              "llm_output_tokens": 221,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 307,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000191322,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4531,
              "llm_output_tokens": 221,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 307,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000191322,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1494.79295,
            "p50": 39.0256,
            "p95": 2950.5603
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3123.7554,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 2995.9783,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 251,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 39.0256,
                "p50": 39.0256,
                "p95": 39.0256
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4531,
                  "llm_output_tokens": 221,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 307,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000191322,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4531,
                  "llm_output_tokens": 221,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 307,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000191322,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2950.5603,
                "p50": 2950.5603,
                "p95": 2950.5603
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4688,
              "llm_output_tokens": 308,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 336,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000248256,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4688,
              "llm_output_tokens": 308,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 336,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000248256,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1078.5019499999999,
            "p50": 57.6274,
            "p95": 2099.3765
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2281.5309,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2142.3968,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 249,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 57.6274,
                "p50": 57.6274,
                "p95": 57.6274
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4688,
                  "llm_output_tokens": 308,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000248256,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4688,
                  "llm_output_tokens": 308,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000248256,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2099.3765,
                "p50": 2099.3765,
                "p95": 2099.3765
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4461,
              "llm_output_tokens": 58,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 365,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000101838,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4461,
              "llm_output_tokens": 58,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 365,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000101838,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 969.2196,
            "p50": 969.2196,
            "p95": 969.2196
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1052.4928,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 266,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4461,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 365,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000101838,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4461,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 365,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000101838,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 969.2196,
                "p50": 969.2196,
                "p95": 969.2196
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2193,
              "llm_output_tokens": 73,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 145,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 7.1694e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2193,
              "llm_output_tokens": 73,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 145,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 7.1694e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 483.1598,
            "p50": 49.8351,
            "p95": 916.4845
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1110.5836,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 971.84,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 246,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 49.8351,
                "p50": 49.8351,
                "p95": 49.8351
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2193,
                  "llm_output_tokens": 73,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 145,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 7.1694e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2193,
                  "llm_output_tokens": 73,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 145,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 7.1694e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 916.4845,
                "p50": 916.4845,
                "p95": 916.4845
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7373,
              "llm_output_tokens": 528,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 717,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00044431799999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7373,
              "llm_output_tokens": 528,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 717,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00044431799999999997,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1157.1375666666668,
            "p50": 661.5831,
            "p95": 2748.3609
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3662.9065,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3505.3004,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 243,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.4687,
                "p50": 61.4687,
                "p95": 61.4687
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4796,
                  "llm_output_tokens": 466,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 316,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00034043999999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4796,
                  "llm_output_tokens": 466,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 316,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00034043999999999996,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2748.3609,
                "p50": 2748.3609,
                "p95": 2748.3609
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2577,
                  "llm_output_tokens": 62,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 401,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00010387799999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2577,
                  "llm_output_tokens": 62,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 401,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00010387799999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 661.5831,
                "p50": 661.5831,
                "p95": 661.5831
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2194,
              "llm_output_tokens": 170,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 146,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00013004399999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2194,
              "llm_output_tokens": 170,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 146,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00013004399999999998,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 510.66685,
            "p50": 59.2381,
            "p95": 962.0956
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1155.556,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1006.2818,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 241,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 59.2381,
                "p50": 59.2381,
                "p95": 59.2381
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2194,
                  "llm_output_tokens": 170,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 146,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00013004399999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2194,
                  "llm_output_tokens": 170,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 146,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00013004399999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 962.0956,
                "p50": 962.0956,
                "p95": 962.0956
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 6.3444e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 6.3444e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 430.21815,
            "p50": 43.7673,
            "p95": 816.669
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 981.2678,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 856.9585,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 212,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 43.7673,
                "p50": 43.7673,
                "p95": 43.7673
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 6.3444e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 6.3444e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 816.669,
                "p50": 816.669,
                "p95": 816.669
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4399,
              "llm_output_tokens": 83,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 303,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000107538,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4399,
              "llm_output_tokens": 83,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 303,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000107538,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 532.4024,
            "p50": 661.5609,
            "p95": 849.7803
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1776.4712,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1602.9708,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 209,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 85.866,
                "p50": 85.866,
                "p95": 85.866
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 27,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 4.3494e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 27,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 4.3494e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 661.5609,
                "p50": 661.5609,
                "p95": 661.5609
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2210,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 162,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 6.404400000000001e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2210,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 162,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 6.404400000000001e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 849.7803,
                "p50": 849.7803,
                "p95": 849.7803
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 6.5544e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 63,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 6.5544e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 567.51165,
            "p50": 77.5369,
            "p95": 1057.4864
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1255.6078,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1100.7506,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 208,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 77.5369,
                "p50": 77.5369,
                "p95": 77.5369
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 6.5544e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 63,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 6.5544e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1057.4864,
                "p50": 1057.4864,
                "p95": 1057.4864
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7003,
              "llm_output_tokens": 454,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 603,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00038204999999999994,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7003,
              "llm_output_tokens": 454,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 603,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00038204999999999994,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1246.1238666666666,
            "p50": 758.2119,
            "p95": 2891.5433
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3896.4442,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 793.8932,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 215,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 88.6164,
                "p50": 88.6164,
                "p95": 88.6164
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4812,
                  "llm_output_tokens": 393,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 460,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000317856,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4812,
                  "llm_output_tokens": 393,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 460,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000317856,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2891.5433,
                "p50": 2891.5433,
                "p95": 2891.5433
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2191,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 143,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 6.4194e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2191,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 143,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 6.4194e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 758.2119,
                "p50": 758.2119,
                "p95": 758.2119
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 118,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 9.8244e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2190,
              "llm_output_tokens": 118,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 142,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 9.8244e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 512.0824,
            "p50": 42.8453,
            "p95": 981.3195
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1145.8346,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1016.915,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 223,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 42.8453,
                "p50": 42.8453,
                "p95": 42.8453
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 118,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 9.8244e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2190,
                  "llm_output_tokens": 118,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 142,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 9.8244e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 981.3195,
                "p50": 981.3195,
                "p95": 981.3195
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 111,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 9.539399999999999e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2199,
              "llm_output_tokens": 111,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 151,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 9.539399999999999e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 449.2391,
            "p50": 59.6303,
            "p95": 838.8479
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1015.7949,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 878.0579,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 263,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 59.6303,
                "p50": 59.6303,
                "p95": 59.6303
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 111,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 9.539399999999999e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2199,
                  "llm_output_tokens": 111,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 151,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 9.539399999999999e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 838.8479,
                "p50": 838.8479,
                "p95": 838.8479
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2197,
              "llm_output_tokens": 306,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 149,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000212094,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2197,
              "llm_output_tokens": 306,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 149,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000212094,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 943.2504,
            "p50": 57.7527,
            "p95": 1828.7481
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2015.5552,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1871.36,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 226,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 57.7527,
                "p50": 57.7527,
                "p95": 57.7527
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2197,
                  "llm_output_tokens": 306,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000212094,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2197,
                  "llm_output_tokens": 306,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 149,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000212094,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1828.7481,
                "p50": 1828.7481,
                "p95": 1828.7481
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4451,
              "llm_output_tokens": 266,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 355,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022513799999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4451,
              "llm_output_tokens": 266,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 355,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00022513799999999997,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 847.5281333333334,
            "p50": 898.7438,
            "p95": 1578.1025
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2720.9455,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2576.9241,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 220,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 65.7381,
                "p50": 65.7381,
                "p95": 65.7381
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 196,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000144894,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2189,
                  "llm_output_tokens": 196,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 141,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000144894,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1578.1025,
                "p50": 1578.1025,
                "p95": 1578.1025
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2262,
                  "llm_output_tokens": 70,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 214,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 8.0244e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2262,
                  "llm_output_tokens": 70,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 214,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 8.0244e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 898.7438,
                "p50": 898.7438,
                "p95": 898.7438
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2215,
              "llm_output_tokens": 107,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 167,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 9.5394e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2215,
              "llm_output_tokens": 107,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 167,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 9.5394e-05,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 625.79185,
            "p50": 82.6696,
            "p95": 1168.9141
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1387.6449,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1213.9097,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 228,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 82.6696,
                "p50": 82.6696,
                "p95": 82.6696
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2215,
                  "llm_output_tokens": 107,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 167,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 9.5394e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2215,
                  "llm_output_tokens": 107,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 167,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 9.5394e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1168.9141,
                "p50": 1168.9141,
                "p95": 1168.9141
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 136,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00010934399999999999,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 136,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00010934399999999999,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 491.31095000000005,
            "p50": 72.7996,
            "p95": 909.8223
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1107.6593,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 953.528,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 218,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 72.7996,
                "p50": 72.7996,
                "p95": 72.7996
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 136,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00010934399999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 136,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00010934399999999999,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 909.8223,
                "p50": 909.8223,
                "p95": 909.8223
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4457,
              "llm_output_tokens": 87,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 361,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00011863800000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4457,
              "llm_output_tokens": 87,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 361,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00011863800000000001,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1868.318,
            "p50": 1868.318,
            "p95": 1868.318
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1955.0944,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 259,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4457,
                  "llm_output_tokens": 87,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 361,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00011863800000000001,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4457,
                  "llm_output_tokens": 87,
                  "llm_cache_hit_tokens": 4096,
                  "llm_cache_miss_tokens": 361,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00011863800000000001,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1868.318,
                "p50": 1868.318,
                "p95": 1868.318
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4570,
              "llm_output_tokens": 199,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 346,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000183972,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4570,
              "llm_output_tokens": 199,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 346,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000183972,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2297.3892,
            "p50": 2297.3892,
            "p95": 2297.3892
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2391.3847,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 261,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4570,
                  "llm_output_tokens": 199,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 346,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000183972,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4570,
                  "llm_output_tokens": 199,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 346,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000183972,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2297.3892,
                "p50": 2297.3892,
                "p95": 2297.3892
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7135,
              "llm_output_tokens": 401,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 607,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00035123399999999996,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7135,
              "llm_output_tokens": 401,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 607,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00035123399999999996,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 3355.6716,
            "p50": 3355.6716,
            "p95": 3355.6716
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": false,
          "errors": [
            "expected parameter-correct pending action before authorization",
            "cancel did not exercise correct preview"
          ],
          "setup_error": false,
          "duration_ms": 3440.4511,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 236,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7135,
                  "llm_output_tokens": 401,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 607,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00035123399999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7135,
                  "llm_output_tokens": 401,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 607,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00035123399999999996,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3355.6716,
                "p50": 3355.6716,
                "p95": 3355.6716
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 125,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000102744,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2192,
              "llm_output_tokens": 125,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 144,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000102744,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 655.6527,
            "p50": 70.2783,
            "p95": 1241.0271
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1459.9606,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1286.5794,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 239,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 70.2783,
                "p50": 70.2783,
                "p95": 70.2783
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 125,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000102744,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2192,
                  "llm_output_tokens": 125,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 144,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000102744,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1241.0271,
                "p50": 1241.0271,
                "p95": 1241.0271
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7162,
              "llm_output_tokens": 316,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 762,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00032310000000000005,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7162,
              "llm_output_tokens": 316,
              "llm_cache_hit_tokens": 6400,
              "llm_cache_miss_tokens": 762,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.00032310000000000005,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1104.0486333333333,
            "p50": 1097.8561,
            "p95": 2145.1941
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3508.1758,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3346.4882,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 234,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.0957,
                "p50": 69.0957,
                "p95": 69.0957
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 256,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022477199999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4614,
                  "llm_output_tokens": 256,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 390,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.00022477199999999998,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2145.1941,
                "p50": 2145.1941,
                "p95": 2145.1941
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2548,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 372,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 9.8328e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2548,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 372,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 9.8328e-05,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1097.8561,
                "p50": 1097.8561,
                "p95": 1097.8561
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7102,
              "llm_output_tokens": 343,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 574,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000311484,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7102,
              "llm_output_tokens": 343,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 574,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000311484,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1537.95655,
            "p50": 64.8227,
            "p95": 3011.0904
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3209.2238,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3053.9525,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 230,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 64.8227,
                "p50": 64.8227,
                "p95": 64.8227
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7102,
                  "llm_output_tokens": 343,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 574,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000311484,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7102,
                  "llm_output_tokens": 343,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 574,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000311484,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3011.0904,
                "p50": 3011.0904,
                "p95": 3011.0904
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4533,
              "llm_output_tokens": 162,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 309,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000156222,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4533,
              "llm_output_tokens": 162,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 309,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000156222,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1568.29,
            "p50": 1568.29,
            "p95": 1568.29
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1665.0473,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 256,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4533,
                  "llm_output_tokens": 162,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 309,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000156222,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4533,
                  "llm_output_tokens": 162,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 309,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.000156222,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1568.29,
                "p50": 1568.29,
                "p95": 1568.29
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 2044.882125,
        "p50": 1757.7827,
        "p95": 3662.9065
      },
      "latency_successful_tasks_ms": {
        "count": 23,
        "average": 1984.2052130434784,
        "p50": 1757.7827,
        "p95": 3662.9065
      },
      "failure_details": [
        {
          "id": "subscribe-cancel",
          "errors": [
            "expected parameter-correct pending action before authorization",
            "cancel did not exercise correct preview"
          ],
          "setup_error": false,
          "fast_selected": false
        }
      ],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 43.868325,
            "p50": 42.8453,
            "p95": 49.8351
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 69.51003571428572,
            "p50": 65.7381,
            "p95": 88.6164
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4812,
              "llm_output_tokens": 393,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 460,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000317856,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4812,
              "llm_output_tokens": 393,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 460,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000317856,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2891.5433,
            "p50": 2891.5433,
            "p95": 2891.5433
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 70071,
              "llm_output_tokens": 3169,
              "llm_cache_hit_tokens": 64896,
              "llm_cache_miss_tokens": 5175,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 31,
            "usage_responses": 31,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 20
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.002872338,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 70071,
              "llm_output_tokens": 3169,
              "llm_cache_hit_tokens": 64896,
              "llm_cache_miss_tokens": 5175,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.002872338,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 1562.907545,
            "p50": 1168.9141,
            "p95": 3011.0904
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 13788,
              "llm_output_tokens": 945,
              "llm_cache_hit_tokens": 12800,
              "llm_cache_miss_tokens": 988,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0007536,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 13788,
              "llm_output_tokens": 945,
              "llm_cache_hit_tokens": 12800,
              "llm_cache_miss_tokens": 988,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0007536,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1783.3046,
            "p50": 1578.1025,
            "p95": 2748.3609
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9597,
              "llm_output_tokens": 248,
              "llm_cache_hit_tokens": 8448,
              "llm_cache_miss_tokens": 1149,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000346494,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9597,
              "llm_output_tokens": 248,
              "llm_cache_hit_tokens": 8448,
              "llm_cache_miss_tokens": 1149,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.000346494,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 876.990825,
            "p50": 849.7803,
            "p95": 1097.8561
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    },
    "hint": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 98755,
          "llm_output_tokens": 4553,
          "llm_cache_hit_tokens": 89472,
          "llm_cache_miss_tokens": 9283,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 42,
        "usage_responses": 42,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "openai": 29,
          "unreported": 19
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 44786,
          "jev_output_tokens": 5811
        },
        "usage_responses": 48,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.0062736779999999995,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.003,
          "cache_miss_input_per_million": 0.15,
          "output_per_million": 0.6,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 98755,
          "llm_output_tokens": 4553,
          "llm_cache_hit_tokens": 89472,
          "llm_cache_miss_tokens": 9283,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 44786,
          "jev_output_tokens": 5811
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 48,
        "llm_estimate": 0.004392665999999999,
        "jev_estimate": 0.0018810120000000003
      },
      "llm_attempts_complete": true,
      "turn_attempts": 48,
      "request_latency_all_ms": {
        "count": 48,
        "average": 1183.1019895833333,
        "p50": 1279.9218,
        "p95": 2940.1962
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 24,
        "completion_rate": 1,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 2,
        "preview_observed": 19,
        "preview_correct": 19,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 5,
        "cancel_no_write_observed": 5,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 42,
        "telemetry_turns": 48,
        "all_task_latency": {
          "count": 24,
          "average_ms": 2498.842304166667,
          "p50_ms": 2106.1397,
          "p95_ms": 4683.8696
        },
        "successful_task_latency": {
          "count": 24,
          "average_ms": 2498.842304166667,
          "p50_ms": 2106.1397,
          "p95_ms": 4683.8696
        },
        "time_to_preview": {
          "count": 19,
          "average_ms": 2396.190847368421,
          "p50_ms": 2157.678,
          "p95_ms": 4727.1569
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-hint",
        "jev_mode": "on",
        "model": "deepseek-flash",
        "source_git": "f83b6498e9a9c4faf3329486aae4ca4cd85ee22a",
        "binary_sha256": "64c67789ab95ef3d2a23f3a709b7e6c7a9e819ba98615bf395bd821bc85f9f2e",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 89,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000174642,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 89,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000123822,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1966.1279,
            "p50": 1966.1279,
            "p95": 1966.1279
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2052.2069,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 262,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 89,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000174642,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 89,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000123822,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1966.1279,
                "p50": 1966.1279,
                "p95": 1966.1279
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4781,
              "llm_output_tokens": 228,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 429,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00028552199999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4781,
              "llm_output_tokens": 228,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 429,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00021420599999999996,
            "jev_estimate": 7.1316e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1154.71155,
            "p50": 40.7946,
            "p95": 2268.6285
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2450.7304,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 2311.1664,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 258,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 40.7946,
                "p50": 40.7946,
                "p95": 40.7946
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4781,
                  "llm_output_tokens": 228,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 429,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00028552199999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4781,
                  "llm_output_tokens": 228,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 429,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00021420599999999996,
                "jev_estimate": 7.1316e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2268.6285,
                "p50": 2268.6285,
                "p95": 2268.6285
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4795,
              "llm_output_tokens": 175,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 443,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000256746,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4795,
              "llm_output_tokens": 175,
              "llm_cache_hit_tokens": 4352,
              "llm_cache_miss_tokens": 443,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000184506,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1350.29285,
            "p50": 65.4695,
            "p95": 2635.1162
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2840.7784,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2685.5929,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 254,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 65.4695,
                "p50": 65.4695,
                "p95": 65.4695
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4795,
                  "llm_output_tokens": 175,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 443,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000256746,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4795,
                  "llm_output_tokens": 175,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 443,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000184506,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2635.1162,
                "p50": 2635.1162,
                "p95": 2635.1162
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4621,
              "llm_output_tokens": 67,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 397,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00016374600000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4621,
              "llm_output_tokens": 67,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 397,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000112422,
            "jev_estimate": 5.1324000000000005e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2023.6122,
            "p50": 2023.6122,
            "p95": 2023.6122
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2106.1397,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 274,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4621,
                  "llm_output_tokens": 67,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 397,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00016374600000000001,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4621,
                  "llm_output_tokens": 67,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 397,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000112422,
                "jev_estimate": 5.1324000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2023.6122,
                "p50": 2023.6122,
                "p95": 2023.6122
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 205,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000234834,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 205,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00016259399999999998,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1076.1861000000001,
            "p50": 43.4324,
            "p95": 2108.9398
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2284.9893,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 2157.678,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 252,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 43.4324,
                "p50": 43.4324,
                "p95": 43.4324
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 205,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000234834,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 205,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00016259399999999998,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2108.9398,
                "p50": 2108.9398,
                "p95": 2108.9398
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7522,
              "llm_output_tokens": 525,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 738,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000568692,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7522,
              "llm_output_tokens": 525,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 738,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000446052,
            "jev_estimate": 0.00012264
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1565.8597333333335,
            "p50": 1279.9218,
            "p95": 3354.1956
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 4880.8584,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 4727.1569,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 247,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 63.4618,
                "p50": 63.4618,
                "p95": 63.4618
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4913,
                  "llm_output_tokens": 460,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 433,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000404874,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4913,
                  "llm_output_tokens": 460,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 433,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00035439,
                "jev_estimate": 5.0484e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3354.1956,
                "p50": 3354.1956,
                "p95": 3354.1956
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2609,
                  "llm_output_tokens": 65,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 305,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000163818,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2609,
                  "llm_output_tokens": 65,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 305,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 9.1662e-05,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1279.9218,
                "p50": 1279.9218,
                "p95": 1279.9218
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 186,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00022392,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 186,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000151344,
            "jev_estimate": 7.2576e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 908.83635,
            "p50": 62.8869,
            "p95": 1754.7858
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1983.3789,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1803.76,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 245,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 62.8869,
                "p50": 62.8869,
                "p95": 62.8869
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 186,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00022392,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 186,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000151344,
                "jev_estimate": 7.2576e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1754.7858,
                "p50": 1754.7858,
                "p95": 1754.7858
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 57,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000144762,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 57,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 7.319399999999999e-05,
            "jev_estimate": 7.1568e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 592.6933,
            "p50": 48.8413,
            "p95": 1136.5453
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1325.2743,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1179.8199,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 210,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 48.8413,
                "p50": 48.8413,
                "p95": 48.8413
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000144762,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 57,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.319399999999999e-05,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1136.5453,
                "p50": 1136.5453,
                "p95": 1136.5453
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 85,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000253848,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 85,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000131838,
            "jev_estimate": 0.00012201
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 925.9117666666667,
            "p50": 888.9459,
            "p95": 1788.0976
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2956.5639,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2764.0602,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 206,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 100.6918,
                "p50": 100.6918,
                "p95": 100.6918
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 33,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00010908599999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 33,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 5.864399999999999e-05,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 888.9459,
                "p50": 888.9459,
                "p95": 888.9459
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 52,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000144762,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 52,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.3194e-05,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1788.0976,
                "p50": 1788.0976,
                "p95": 1788.0976
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 77,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000157566,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 77,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 8.5494e-05,
            "jev_estimate": 7.2072e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 795.8631,
            "p50": 85.5598,
            "p95": 1506.1664
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1712.2203,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1551.0364,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 205,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 85.5598,
                "p50": 85.5598,
                "p95": 85.5598
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 77,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000157566,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 77,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 8.5494e-05,
                "jev_estimate": 7.2072e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1506.1664,
                "p50": 1506.1664,
                "p95": 1506.1664
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4541,
              "llm_output_tokens": 156,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 445,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00029468999999999996,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4541,
              "llm_output_tokens": 156,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 445,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.00017263799999999997,
            "jev_estimate": 0.000122052
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 819.6705000000001,
            "p50": 1141.3742,
            "p95": 1225.4853
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2619.5381,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1178.9043,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 213,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 92.152,
                "p50": 92.152,
                "p95": 92.152
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2273,
                  "llm_output_tokens": 105,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 225,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00015321,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2273,
                  "llm_output_tokens": 105,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 225,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00010289400000000001,
                "jev_estimate": 5.0316000000000004e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1225.4853,
                "p50": 1225.4853,
                "p95": 1225.4853
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 51,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00014148,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 51,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 6.9744e-05,
                "jev_estimate": 7.1736e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1141.3742,
                "p50": 1141.3742,
                "p95": 1141.3742
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 93,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000166704,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 93,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 9.5094e-05,
            "jev_estimate": 7.161e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 828.56555,
            "p50": 38.8865,
            "p95": 1618.2446
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1767.3301,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1655.6196,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 222,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 38.8865,
                "p50": 38.8865,
                "p95": 38.8865
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 93,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000166704,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 93,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 9.5094e-05,
                "jev_estimate": 7.161e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1618.2446,
                "p50": 1618.2446,
                "p95": 1618.2446
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000185472,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 120,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000112644,
            "jev_estimate": 7.2828e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 791.9114000000001,
            "p50": 54.9715,
            "p95": 1528.8513
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1700.9571,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1572.2076,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 272,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 54.9715,
                "p50": 54.9715,
                "p95": 54.9715
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000185472,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 120,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000112644,
                "jev_estimate": 7.2828e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1528.8513,
                "p50": 1528.8513,
                "p95": 1528.8513
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 307,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000297162,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2276,
              "llm_output_tokens": 307,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 228,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00022454399999999997,
            "jev_estimate": 7.261800000000002e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1287.77505,
            "p50": 58.9316,
            "p95": 2516.6185
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2701.4403,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2561.078,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 225,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 58.9316,
                "p50": 58.9316,
                "p95": 58.9316
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 307,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000297162,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2276,
                  "llm_output_tokens": 307,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 228,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00022454399999999997,
                "jev_estimate": 7.261800000000002e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2516.6185,
                "p50": 2516.6185,
                "p95": 2516.6185
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4617,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 393,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00029781,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4617,
              "llm_output_tokens": 173,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 393,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000175422,
            "jev_estimate": 0.000122388
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 961.8269,
            "p50": 1344.9537,
            "p95": 1476.4003
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3045.4046,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2897.5411,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 219,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 64.1267,
                "p50": 64.1267,
                "p95": 64.1267
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 109,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00015498599999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 109,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00010454399999999998,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1476.4003,
                "p50": 1476.4003,
                "p95": 1476.4003
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2349,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 173,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000142824,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2349,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 173,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.0878e-05,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1344.9537,
                "p50": 1344.9537,
                "p95": 1344.9537
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 117,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1821,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00019017600000000002,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 117,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1821,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000113694,
            "jev_estimate": 7.6482e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 905.07145,
            "p50": 67.8695,
            "p95": 1742.2734
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1925.2834,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1780.5249,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 229,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 67.8695,
                "p50": 67.8695,
                "p95": 67.8695
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 117,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1821,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00019017600000000002,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 117,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1821,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000113694,
                "jev_estimate": 7.6482e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1742.2734,
                "p50": 1742.2734,
                "p95": 1742.2734
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 157,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00020574,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 157,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000133794,
            "jev_estimate": 7.194599999999999e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 881.32605,
            "p50": 55.7469,
            "p95": 1706.9052
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1883.7659,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1746.6537,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 216,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 55.7469,
                "p50": 55.7469,
                "p95": 55.7469
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 157,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00020574,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 157,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000133794,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1706.9052,
                "p50": 1706.9052,
                "p95": 1706.9052
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4611,
              "llm_output_tokens": 81,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 387,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000170142,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4611,
              "llm_output_tokens": 81,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 387,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00011932200000000001,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1781.6782,
            "p50": 1781.6782,
            "p95": 1781.6782
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1861.0373,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 269,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4611,
                  "llm_output_tokens": 81,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 387,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000170142,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4611,
                  "llm_output_tokens": 81,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 387,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00011932200000000001,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1781.6782,
                "p50": 1781.6782,
                "p95": 1781.6782
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4718,
              "llm_output_tokens": 270,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 494,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000300138,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4718,
              "llm_output_tokens": 270,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 494,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00024877199999999997,
            "jev_estimate": 5.1366e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2175.8862,
            "p50": 2175.8862,
            "p95": 2175.8862
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2282.1709,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 271,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4718,
                  "llm_output_tokens": 270,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 494,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000300138,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4718,
                  "llm_output_tokens": 270,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 494,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00024877199999999997,
                "jev_estimate": 5.1366e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2175.8862,
                "p50": 2175.8862,
                "p95": 2175.8862
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7258,
              "llm_output_tokens": 389,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 602,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00041582399999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7258,
              "llm_output_tokens": 389,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 602,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000343668,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1884.51435,
            "p50": 40.5548,
            "p95": 3728.4739
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3885.1302,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3768.7766,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 238,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 40.5548,
                "p50": 40.5548,
                "p95": 40.5548
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7258,
                  "llm_output_tokens": 389,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 602,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00041582399999999997,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7258,
                  "llm_output_tokens": 389,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 602,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000343668,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3728.4739,
                "p50": 3728.4739,
                "p95": 3728.4739
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 149,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000201,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 149,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000128844,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 831.6650000000001,
            "p50": 81.3158,
            "p95": 1582.0142
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1854.2236,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1664.3046,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 242,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 81.3158,
                "p50": 81.3158,
                "p95": 81.3158
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 149,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000201,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 149,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000128844,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1582.0142,
                "p50": 1582.0142,
                "p95": 1582.0142
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7420,
              "llm_output_tokens": 339,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 764,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00046073399999999997,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7420,
              "llm_output_tokens": 339,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 764,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.00033796799999999996,
            "jev_estimate": 0.000122766
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1506.5770333333332,
            "p50": 1845.7957,
            "p95": 2615.5433
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 4683.8696,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 4538.1794,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 235,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 58.3921,
                "p50": 58.3921,
                "p95": 58.3921
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4776,
                  "llm_output_tokens": 284,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 424,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00029766600000000003,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4776,
                  "llm_output_tokens": 284,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 424,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000247056,
                "jev_estimate": 5.0610000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2615.5433,
                "p50": 2615.5433,
                "p95": 2615.5433
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2644,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 340,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000163068,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2644,
                  "llm_output_tokens": 55,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 340,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 9.0912e-05,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1845.7957,
                "p50": 1845.7957,
                "p95": 1845.7957
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7277,
              "llm_output_tokens": 333,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 621,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00038524200000000005,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7277,
              "llm_output_tokens": 333,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 621,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00031291800000000003,
            "jev_estimate": 7.2324e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1507.83185,
            "p50": 75.4675,
            "p95": 2940.1962
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3163.8395,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2983.5656,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 231,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 75.4675,
                "p50": 75.4675,
                "p95": 75.4675
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7277,
                  "llm_output_tokens": 333,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 621,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00038524200000000005,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7277,
                  "llm_output_tokens": 333,
                  "llm_cache_hit_tokens": 6656,
                  "llm_cache_miss_tokens": 621,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00031291800000000003,
                "jev_estimate": 7.2324e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2940.1962,
                "p50": 2940.1962,
                "p95": 2940.1962
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4692,
              "llm_output_tokens": 175,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 468,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000238566,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4692,
              "llm_output_tokens": 175,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 468,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000187872,
            "jev_estimate": 5.0694e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1907.5653,
            "p50": 1907.5653,
            "p95": 1907.5653
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2005.0842,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 264,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4692,
                  "llm_output_tokens": 175,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 468,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000238566,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4692,
                  "llm_output_tokens": 175,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 468,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000187872,
                "jev_estimate": 5.0694e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1907.5653,
                "p50": 1907.5653,
                "p95": 1907.5653
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 2498.8423041666665,
        "p50": 2106.1397,
        "p95": 4683.8696
      },
      "latency_successful_tasks_ms": {
        "count": 24,
        "average": 2498.8423041666665,
        "p50": 2106.1397,
        "p95": 4683.8696
      },
      "failure_details": [],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 5
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 5,
          "request_latency_all_ms": {
            "count": 5,
            "average": 42.50192,
            "p50": 40.7946,
            "p95": 48.8413
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 70.5031,
            "p50": 64.1267,
            "p95": 100.6918
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2273,
              "llm_output_tokens": 105,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 225,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00015321,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2273,
              "llm_output_tokens": 105,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 225,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00010289400000000001,
            "jev_estimate": 5.0316000000000004e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1225.4853,
            "p50": 1225.4853,
            "p95": 1225.4853
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 72370,
              "llm_output_tokens": 3326,
              "llm_cache_hit_tokens": 65664,
              "llm_cache_miss_tokens": 6706,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 31,
            "usage_responses": 31,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 20
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 31926,
              "jev_output_tokens": 4051
            },
            "usage_responses": 35,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0045393840000000005,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 72370,
              "llm_output_tokens": 3326,
              "llm_cache_hit_tokens": 65664,
              "llm_cache_miss_tokens": 6706,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 31926,
              "jev_output_tokens": 4051
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 35,
            "llm_estimate": 0.0031984920000000003,
            "jev_estimate": 0.001340892
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 1988.500165,
            "p50": 1781.6782,
            "p95": 2940.1962
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 14223,
              "llm_output_tokens": 886,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1295,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000966612,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 14223,
              "llm_output_tokens": 886,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1295,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 4,
            "llm_estimate": 0.000764634,
            "jev_estimate": 0.000201978
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 2083.771275,
            "p50": 1476.4003,
            "p95": 3354.1956
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9889,
              "llm_output_tokens": 236,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1057,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "usage_responses": 8,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000614472,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9889,
              "llm_output_tokens": 236,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1057,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 8,
            "llm_estimate": 0.00032664599999999994,
            "jev_estimate": 0.00028782600000000003
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1564.6922,
            "p50": 1344.9537,
            "p95": 1845.7957
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    },
    "fast": {
      "usage": {
        "observed_tokens": {
          "llm_input_tokens": 89873,
          "llm_output_tokens": 4671,
          "llm_cache_hit_tokens": 81280,
          "llm_cache_miss_tokens": 8593,
          "llm_cache_creation_tokens": 0
        },
        "observed_llm_attempts": 38,
        "usage_responses": 38,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": [],
        "protocols": {
          "unreported": 21,
          "openai": 27
        }
      },
      "jev_usage": {
        "observed_tokens": {
          "jev_input_tokens": 44780,
          "jev_output_tokens": 5811
        },
        "usage_responses": 48,
        "usage_missing_responses": 0,
        "complete": true,
        "complete_sample_ids": [
          "balance-read:0",
          "cancel-abort:0",
          "cancel-abort:1",
          "cancel-subscription:0",
          "cancel-subscription:1",
          "cancelled-read:0",
          "change-cancel:0",
          "change-cancel:1",
          "change-missing:0",
          "change-missing:1",
          "change-missing:2",
          "change-ready:0",
          "change-ready:1",
          "recharge-cancel:0",
          "recharge-cancel:1",
          "recharge-missing:0",
          "recharge-missing:1",
          "recharge-missing:2",
          "recharge-ready:0",
          "recharge-ready:1",
          "recharge-repeat:0",
          "recharge-repeat:1",
          "recharge-repeat:2",
          "refund-cancel:0",
          "refund-cancel:1",
          "refund-capped:0",
          "refund-capped:1",
          "refund-composite:0",
          "refund-composite:1",
          "refund-missing:0",
          "refund-missing:1",
          "refund-missing:2",
          "refund-order:0",
          "refund-order:1",
          "refund-ready:0",
          "refund-ready:1",
          "satisfied-balance:0",
          "satisfied-subscription:0",
          "subscribe-cancel:0",
          "subscribe-cancel:1",
          "subscribe-flagship:0",
          "subscribe-flagship:1",
          "subscribe-missing:0",
          "subscribe-missing:1",
          "subscribe-missing:2",
          "subscribe-ready:0",
          "subscribe-ready:1",
          "subscription-read:0"
        ],
        "missing_sample_ids": []
      },
      "estimated_cost": {
        "total": 0.00621615,
        "currency": "USD",
        "reason": "estimate under supplied prices; not an actual invoiced fee",
        "assumptions": {
          "currency": "USD",
          "cache_hit_input_per_million": 0.003,
          "cache_miss_input_per_million": 0.15,
          "output_per_million": 0.6,
          "jev_input_per_million": 0.042,
          "jev_output_per_million": 0,
          "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
          "checked_at": "2026-10-08T11:55:23.5138153Z",
          "sources": [
            "https://api-docs.deepseek.com/quick_start/pricing/",
            "https://typesafe.ai/",
            "https://api.typesafe.ai/openapi.json"
          ]
        },
        "observed_units": {
          "llm_input_tokens": 89873,
          "llm_output_tokens": 4671,
          "llm_cache_hit_tokens": 81280,
          "llm_cache_miss_tokens": 8593,
          "llm_cache_creation_tokens": 0
        },
        "jev_observed_units": {
          "jev_input_tokens": 44780,
          "jev_output_tokens": 5811
        },
        "jev_usage_complete": true,
        "jev_pricing_basis": "tokens",
        "jev_requests": 48,
        "llm_estimate": 0.00433539,
        "jev_estimate": 0.0018807600000000002
      },
      "llm_attempts_complete": true,
      "turn_attempts": 48,
      "request_latency_all_ms": {
        "count": 48,
        "average": 1181.3946020833334,
        "p50": 1292.0341,
        "p95": 3575.7527
      },
      "request_failure_details": [],
      "fast_status_missing_turn_ids": [],
      "missing_raw_telemetry_ids": [],
      "source_metrics": {
        "total": 24,
        "completed": 24,
        "completion_rate": 1,
        "by_category": {
          "already_satisfied": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "cancel_subscription": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "change": {
            "total": 3,
            "completed": 3,
            "completion_rate": 1
          },
          "read": {
            "total": 2,
            "completed": 2,
            "completion_rate": 1
          },
          "recharge": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          },
          "refund": {
            "total": 6,
            "completed": 6,
            "completion_rate": 1
          },
          "subscribe": {
            "total": 4,
            "completed": 4,
            "completion_rate": 1
          }
        },
        "failed_http": 0,
        "fixture_failures": 0,
        "clarification_required": 4,
        "clarification_offered": 4,
        "clarification_coverage": 1,
        "clarification_completed": 4,
        "redundant_clarifications": 1,
        "preview_observed": 19,
        "preview_correct": 19,
        "preview_parameter_accuracy": 1,
        "premature_writes": 0,
        "cancel_cases": 5,
        "cancel_no_write": 5,
        "cancel_no_write_observed": 5,
        "duplicate_confirm_cases": 1,
        "duplicate_confirm_passed": 1,
        "llm_calls": 38,
        "telemetry_turns": 48,
        "all_task_latency": {
          "count": 24,
          "average_ms": 2496.048891666667,
          "p50_ms": 2214.4965,
          "p95_ms": 4073.0813
        },
        "successful_task_latency": {
          "count": 24,
          "average_ms": 2496.048891666667,
          "p50_ms": 2214.4965,
          "p95_ms": 4073.0813
        },
        "time_to_preview": {
          "count": 19,
          "average_ms": 2500.863242105263,
          "p50_ms": 2062.2998,
          "p95_ms": 4530.7533
        }
      },
      "source_limitations": [
        "Small frozen billing regression suite; not general model accuracy.",
        "Clarification is a slot-oriented text rubric, not semantic understanding proof.",
        "Subscription read identity accepts the exact observed plan ID or canonical catalogue name; contradictory IDs/names fail. The v1 oracle was overly strict about the 套餐# prefix and its historical reports remain unchanged.",
        "Synthetic followups have zero user think time; fixture setup excluded, final state verification included.",
        "Completion requires authoritative state, confirmation timing and parameter evidence; tool selection alone earns no credit.",
        "Cancellation no-write observation is separate from successful cancellation, which also requires no pending action.",
        "Fixture tenants, credentials hashes, business records and sessions retained for historical verification."
      ],
      "metadata": {
        "version": "r3-fast",
        "jev_mode": "on",
        "model": "deepseek-flash",
        "source_git": "f83b6498e9a9c4faf3329486aae4ca4cd85ee22a",
        "binary_sha256": "64c67789ab95ef3d2a23f3a709b7e6c7a9e819ba98615bf395bd821bc85f9f2e",
        "evaluator_binary_sha256": "f39fecdf8f8e4c514c5866b34655e2248eba64d7f2fe990731aa97c560b352cb"
      },
      "tasks": {
        "balance-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 5.082e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.0,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 343.1719,
            "p50": 343.1719,
            "p95": 343.1719
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 424.9873,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [
            "balance-read:0"
          ],
          "fast_selected": true,
          "tenant_id": 265,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "balance-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 5.082e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 343.1719,
                "p50": 343.1719,
                "p95": 343.1719
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-abort": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4935,
              "llm_output_tokens": 388,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 455,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:0",
              "cancel-abort:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00038580600000000004,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4935,
              "llm_output_tokens": 388,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 455,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1698,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00031449,
            "jev_estimate": 7.1316e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1965.92315,
            "p50": 42.0156,
            "p95": 3889.8307
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 4073.0813,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3944.2447,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 260,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 42.0156,
                "p50": 42.0156,
                "p95": 42.0156
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4935,
                  "llm_output_tokens": 388,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 455,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-abort:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00038580600000000004,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4935,
                  "llm_output_tokens": 388,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 455,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1698,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00031449,
                "jev_estimate": 7.1316e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3889.8307,
                "p50": 3889.8307,
                "p95": 3889.8307
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancel-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2277,
              "llm_output_tokens": 172,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 229,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:0",
              "cancel-subscription:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00021593400000000004,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2277,
              "llm_output_tokens": 172,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 229,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000143694,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 881.6117,
            "p50": 69.8939,
            "p95": 1693.3295
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1898.437,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1749.4691,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 257,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.8939,
                "p50": 69.8939,
                "p95": 69.8939
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2277,
                  "llm_output_tokens": 172,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 229,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancel-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00021593400000000004,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2277,
                  "llm_output_tokens": 172,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 229,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000143694,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1693.3295,
                "p50": 1693.3295,
                "p95": 1693.3295
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "cancelled-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4617,
              "llm_output_tokens": 61,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 393,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancelled-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00015954600000000002,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4617,
              "llm_output_tokens": 61,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 393,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1222,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00010822200000000001,
            "jev_estimate": 5.1324000000000005e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1727.2851,
            "p50": 1727.2851,
            "p95": 1727.2851
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1808.3398,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 275,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4617,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 393,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "cancelled-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00015954600000000002,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4617,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 393,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1222,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00010822200000000001,
                "jev_estimate": 5.1324000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1727.2851,
                "p50": 1727.2851,
                "p95": 1727.2851
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 64,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-cancel:0",
              "change-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000150234,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 64,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1720,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 7.7994e-05,
            "jev_estimate": 7.224000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 791.0296999999999,
            "p50": 41.2945,
            "p95": 1540.7649
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1717.4803,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1591.8415,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 255,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 41.2945,
                "p50": 41.2945,
                "p95": 41.2945
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000150234,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 64,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1720,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.7994e-05,
                "jev_estimate": 7.224000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1540.7649,
                "p50": 1540.7649,
                "p95": 1540.7649
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7593,
              "llm_output_tokens": 532,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 809,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "change-missing:1",
              "change-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000583542,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7593,
              "llm_output_tokens": 532,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 809,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2920,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000460902,
            "jev_estimate": 0.00012264
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1502.3545333333334,
            "p50": 1591.8436,
            "p95": 2848.5369
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 4690.4239,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 4530.7533,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 250,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 66.6831,
                "p50": 66.6831,
                "p95": 66.6831
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4953,
                  "llm_output_tokens": 472,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 473,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000418074,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4953,
                  "llm_output_tokens": 472,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 473,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1202,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00036759,
                "jev_estimate": 5.0484e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2848.5369,
                "p50": 2848.5369,
                "p95": 2848.5369
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2640,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000165468,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2640,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 336,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 9.3312e-05,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1591.8436,
                "p50": 1591.8436,
                "p95": 1591.8436
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "change-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 228,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-ready:0",
              "change-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00024912000000000003,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2272,
              "llm_output_tokens": 228,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 224,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1728,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000176544,
            "jev_estimate": 7.2576e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1038.55,
            "p50": 60.8189,
            "p95": 2016.2811
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2214.4965,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2062.2998,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 248,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 60.8189,
                "p50": 60.8189,
                "p95": 60.8189
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 228,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "change-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00024912000000000003,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2272,
                  "llm_output_tokens": 228,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 224,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1728,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000176544,
                "jev_estimate": 7.2576e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2016.2811,
                "p50": 2016.2811,
                "p95": 2016.2811
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-cancel:0",
              "recharge-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00014656199999999998,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2267,
              "llm_output_tokens": 60,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 219,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1704,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 7.4994e-05,
            "jev_estimate": 7.1568e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 562.8056,
            "p50": 48.6007,
            "p95": 1077.0105
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1263.8968,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1128.9386,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 211,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 48.6007,
                "p50": 48.6007,
                "p95": 48.6007
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00014656199999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2267,
                  "llm_output_tokens": 60,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 219,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.4994e-05,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1077.0105,
                "p50": 1077.0105,
                "p95": 1077.0105
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 89,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-missing:0",
              "recharge-missing:1",
              "recharge-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00025624800000000004,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4553,
              "llm_output_tokens": 89,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 457,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2905,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000134238,
            "jev_estimate": 0.00012201
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 832.7075333333333,
            "p50": 878.9365,
            "p95": 1522.8875
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2671.9158,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2486.0076,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 207,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 96.2986,
                "p50": 96.2986,
                "p95": 96.2986
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 33,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00010908599999999999,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2266,
                  "llm_output_tokens": 33,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 218,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 5.864399999999999e-05,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 878.9365,
                "p50": 878.9365,
                "p95": 878.9365
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000147162,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2287,
                  "llm_output_tokens": 56,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 239,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1704,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.5594e-05,
                "jev_estimate": 7.1568e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1522.8875,
                "p50": 1522.8875,
                "p95": 1522.8875
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 48,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-ready:0",
              "recharge-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000140166,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 48,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1716,
              "jev_output_tokens": 208
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 6.809399999999999e-05,
            "jev_estimate": 7.2072e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1042.8306,
            "p50": 91.0223,
            "p95": 1994.6389
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2224.3227,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2041.286,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 204,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 91.0223,
                "p50": 91.0223,
                "p95": 91.0223
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 48,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000140166,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 48,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1716,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 6.809399999999999e-05,
                "jev_estimate": 7.2072e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1994.6389,
                "p50": 1994.6389,
                "p95": 1994.6389
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "recharge-repeat": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4539,
              "llm_output_tokens": 349,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 443,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:0",
              "recharge-repeat:1",
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00041019,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4539,
              "llm_output_tokens": 349,
              "llm_cache_hit_tokens": 4096,
              "llm_cache_miss_tokens": 443,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2906,
              "jev_output_tokens": 394
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.000288138,
            "jev_estimate": 0.000122052
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1214.4092666666666,
            "p50": 1412.126,
            "p95": 2118.5854
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3805.2218,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1453.305,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 214,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 112.5164,
                "p50": 112.5164,
                "p95": 112.5164
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "duplicate_confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 290,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00026391,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 290,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1198,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000213594,
                "jev_estimate": 5.0316000000000004e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2118.5854,
                "p50": 2118.5854,
                "p95": 2118.5854
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 59,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "recharge-repeat:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00014628,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 59,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1708,
                  "jev_output_tokens": 208
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 7.4544e-05,
                "jev_estimate": 7.1736e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1412.126,
                "p50": 1412.126,
                "p95": 1412.126
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 141,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-cancel:0",
              "refund-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000195504,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2269,
              "llm_output_tokens": 141,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 221,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1705,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000123894,
            "jev_estimate": 7.161e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 942.68565,
            "p50": 61.3531,
            "p95": 1824.0182
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2014.2828,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 1874.5147,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 224,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 61.3531,
                "p50": 61.3531,
                "p95": 61.3531
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 141,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000195504,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2269,
                  "llm_output_tokens": 141,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 221,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1705,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000123894,
                "jev_estimate": 7.161e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1824.0182,
                "p50": 1824.0182,
                "p95": 1824.0182
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-capped": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 115,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-capped:0",
              "refund-capped:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000182472,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2278,
              "llm_output_tokens": 115,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 230,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1734,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00010964400000000001,
            "jev_estimate": 7.2828e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 830.6865,
            "p50": 56.5926,
            "p95": 1604.7804
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1779.3549,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1642.2144,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 273,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 56.5926,
                "p50": 56.5926,
                "p95": 56.5926
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 115,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-capped:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000182472,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2278,
                  "llm_output_tokens": 115,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 230,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1734,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00010964400000000001,
                "jev_estimate": 7.2828e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1604.7804,
                "p50": 1604.7804,
                "p95": 1604.7804
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-composite": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4931,
              "llm_output_tokens": 426,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 451,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-composite:0",
              "refund-composite:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00040930800000000005,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4931,
              "llm_output_tokens": 426,
              "llm_cache_hit_tokens": 4480,
              "llm_cache_miss_tokens": 451,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1729,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00033669,
            "jev_estimate": 7.261800000000002e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1667.07765,
            "p50": 58.3321,
            "p95": 3275.8232
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3453.2875,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3315.5398,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 227,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 58.3321,
                "p50": 58.3321,
                "p95": 58.3321
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4931,
                  "llm_output_tokens": 426,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 451,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-composite:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00040930800000000005,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4931,
                  "llm_output_tokens": 426,
                  "llm_cache_hit_tokens": 4480,
                  "llm_cache_miss_tokens": 451,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1729,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00033669,
                "jev_estimate": 7.261800000000002e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3275.8232,
                "p50": 3275.8232,
                "p95": 3275.8232
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4620,
              "llm_output_tokens": 154,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 396,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-missing:0",
              "refund-missing:1",
              "refund-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00028686,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4620,
              "llm_output_tokens": 154,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 396,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2914,
              "jev_output_tokens": 396
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.00016447199999999998,
            "jev_estimate": 0.000122388
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 908.8824666666667,
            "p50": 1292.0341,
            "p95": 1373.7085
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2903.6338,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2751.8397,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 221,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 60.9048,
                "p50": 60.9048,
                "p95": 60.9048
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 93,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000145386,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2268,
                  "llm_output_tokens": 93,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 220,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1201,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 9.494399999999999e-05,
                "jev_estimate": 5.0442e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1373.7085,
                "p50": 1373.7085,
                "p95": 1373.7085
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2352,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 176,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000141474,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2352,
                  "llm_output_tokens": 61,
                  "llm_cache_hit_tokens": 2176,
                  "llm_cache_miss_tokens": 176,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 6.952799999999999e-05,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1292.0341,
                "p50": 1292.0341,
                "p95": 1292.0341
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-order": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 115,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1815,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-order:0",
              "refund-order:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000188724,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2297,
              "llm_output_tokens": 115,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 249,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1815,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000112494,
            "jev_estimate": 7.623000000000001e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 923.8136000000001,
            "p50": 80.3585,
            "p95": 1767.2687
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1968.3397,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1807.8255,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 232,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 80.3585,
                "p50": 80.3585,
                "p95": 80.3585
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 115,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1815,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-order:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000188724,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2297,
                  "llm_output_tokens": 115,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 249,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1815,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000112494,
                "jev_estimate": 7.623000000000001e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1767.2687,
                "p50": 1767.2687,
                "p95": 1767.2687
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "refund-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 146,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "refund-ready:0",
              "refund-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00019914,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 146,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1713,
              "jev_output_tokens": 209
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000127194,
            "jev_estimate": 7.194599999999999e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 914.08555,
            "p50": 60.0501,
            "p95": 1768.121
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1955.901,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 1816.0176,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 217,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 60.0501,
                "p50": 60.0501,
                "p95": 60.0501
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 146,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "refund-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00019914,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2271,
                  "llm_output_tokens": 146,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 223,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1713,
                  "jev_output_tokens": 209
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000127194,
                "jev_estimate": 7.194599999999999e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1768.121,
                "p50": 1768.121,
                "p95": 1768.121
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-balance": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 79,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-balance:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000168642,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4609,
              "llm_output_tokens": 79,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 385,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1210,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000117822,
            "jev_estimate": 5.082e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 1921.6306,
            "p50": 1921.6306,
            "p95": 1921.6306
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 1996.6897,
          "clarification_offered": false,
          "redundant_clarification": true,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 268,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 79,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-balance:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000168642,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4609,
                  "llm_output_tokens": 79,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 385,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1210,
                  "jev_output_tokens": 186
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000117822,
                "jev_estimate": 5.082e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1921.6306,
                "p50": 1921.6306,
                "p95": 1921.6306
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "satisfied-subscription": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 4713,
              "llm_output_tokens": 194,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 489,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 2,
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "satisfied-subscription:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00025378799999999996,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 4713,
              "llm_output_tokens": 194,
              "llm_cache_hit_tokens": 4224,
              "llm_cache_miss_tokens": 489,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1223,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.00020242199999999998,
            "jev_estimate": 5.1366e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2498.8371,
            "p50": 2498.8371,
            "p95": 2498.8371
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2606.8984,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 270,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4713,
                  "llm_output_tokens": 194,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 489,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "satisfied-subscription:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00025378799999999996,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4713,
                  "llm_output_tokens": 194,
                  "llm_cache_hit_tokens": 4224,
                  "llm_cache_miss_tokens": 489,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1223,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.00020242199999999998,
                "jev_estimate": 5.1366e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2498.8371,
                "p50": 2498.8371,
                "p95": 2498.8371
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7409,
              "llm_output_tokens": 428,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 625,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-cancel:0",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0004430580000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7409,
              "llm_output_tokens": 428,
              "llm_cache_hit_tokens": 6784,
              "llm_cache_miss_tokens": 625,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00037090200000000005,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1821.6011,
            "p50": 67.4495,
            "p95": 3575.7527
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3815.6406,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": true,
          "time_to_preview_ms": 3648.1236,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 240,
          "stage_usage": {
            "cancel": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 67.4495,
                "p50": 67.4495,
                "p95": 67.4495
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7409,
                  "llm_output_tokens": 428,
                  "llm_cache_hit_tokens": 6784,
                  "llm_cache_miss_tokens": 625,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-cancel:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0004430580000000001,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7409,
                  "llm_output_tokens": 428,
                  "llm_cache_hit_tokens": 6784,
                  "llm_cache_miss_tokens": 625,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00037090200000000005,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3575.7527,
                "p50": 3575.7527,
                "p95": 3575.7527
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-flagship": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 229,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-flagship:0",
              "subscribe-flagship:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000249,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2270,
              "llm_output_tokens": 229,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 222,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1718,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.000176844,
            "jev_estimate": 7.2156e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1178.3479000000002,
            "p50": 72.7809,
            "p95": 2283.9149
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 2494.0693,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 2328.2881,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 244,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 72.7809,
                "p50": 72.7809,
                "p95": 72.7809
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 229,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-flagship:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000249,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2270,
                  "llm_output_tokens": 229,
                  "llm_cache_hit_tokens": 2048,
                  "llm_cache_miss_tokens": 222,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.000176844,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2283.9149,
                "p50": 2283.9149,
                "p95": 2283.9149
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7398,
              "llm_output_tokens": 320,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 742,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 2,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-missing:0",
              "subscribe-missing:1",
              "subscribe-missing:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00044603400000000005,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7398,
              "llm_output_tokens": 320,
              "llm_cache_hit_tokens": 6656,
              "llm_cache_miss_tokens": 742,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 2923,
              "jev_output_tokens": 392
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 3,
            "llm_estimate": 0.00032326800000000004,
            "jev_estimate": 0.000122766
          },
          "llm_attempts_complete": true,
          "turn_attempts": 3,
          "request_latency_all_ms": {
            "count": 3,
            "average": 1221.1685666666667,
            "p50": 1358.6495,
            "p95": 2235.9687
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3844.9169,
          "clarification_offered": true,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3682.0308,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 237,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:2"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 68.8875,
                "p50": 68.8875,
                "p95": 68.8875
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request_missing": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 4768,
                  "llm_output_tokens": 262,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 416,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 2,
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.000283266,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 4768,
                  "llm_output_tokens": 262,
                  "llm_cache_hit_tokens": 4352,
                  "llm_cache_miss_tokens": 416,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1205,
                  "jev_output_tokens": 185
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.000232656,
                "jev_estimate": 5.0610000000000005e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 2235.9687,
                "p50": 2235.9687,
                "p95": 2235.9687
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "supply_slot": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 2630,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 326,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 1,
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-missing:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00016276799999999998,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 2630,
                  "llm_output_tokens": 58,
                  "llm_cache_hit_tokens": 2304,
                  "llm_cache_miss_tokens": 326,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1718,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 9.061199999999999e-05,
                "jev_estimate": 7.2156e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 1358.6495,
                "p50": 1358.6495,
                "p95": 1358.6495
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscribe-ready": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 7215,
              "llm_output_tokens": 333,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 687,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 3,
            "usage_responses": 3,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1,
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "usage_responses": 2,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscribe-ready:0",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00039475799999999994,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 7215,
              "llm_output_tokens": 333,
              "llm_cache_hit_tokens": 6528,
              "llm_cache_miss_tokens": 687,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1722,
              "jev_output_tokens": 207
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 2,
            "llm_estimate": 0.00032243399999999997,
            "jev_estimate": 7.2324e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 2,
          "request_latency_all_ms": {
            "count": 2,
            "average": 1843.34195,
            "p50": 69.5583,
            "p95": 3617.1256
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 3825.7844,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": true,
          "preview_correct": true,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": 3661.8618,
          "fast_selected_turn_ids": [],
          "fast_selected": false,
          "tenant_id": 233,
          "stage_usage": {
            "confirm": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:1"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.0,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 0,
                  "jev_output_tokens": 0
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 0,
                "llm_estimate": 0.0,
                "jev_estimate": 0.0
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 69.5583,
                "p50": 69.5583,
                "p95": 69.5583
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            },
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 7215,
                  "llm_output_tokens": 333,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 687,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 3,
                "usage_responses": 3,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "openai": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "usage_responses": 2,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscribe-ready:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 0.00039475799999999994,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 7215,
                  "llm_output_tokens": 333,
                  "llm_cache_hit_tokens": 6528,
                  "llm_cache_miss_tokens": 687,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1722,
                  "jev_output_tokens": 207
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 2,
                "llm_estimate": 0.00032243399999999997,
                "jev_estimate": 7.2324e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 3617.1256,
                "p50": 3617.1256,
                "p95": 3617.1256
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        },
        "subscription-read": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 5.0694e-05,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1207,
              "jev_output_tokens": 187
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.0,
            "jev_estimate": 5.0694e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 368.6678,
            "p50": 368.6678,
            "p95": 368.6678
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": [],
          "success": true,
          "errors": null,
          "setup_error": false,
          "duration_ms": 453.7712,
          "clarification_offered": false,
          "redundant_clarification": false,
          "preview_observed": false,
          "preview_correct": false,
          "premature_write": false,
          "cancel_no_write_observed": false,
          "time_to_preview_ms": null,
          "fast_selected_turn_ids": [
            "subscription-read:0"
          ],
          "fast_selected": true,
          "tenant_id": 267,
          "stage_usage": {
            "request": {
              "usage": {
                "observed_tokens": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "observed_llm_attempts": 0,
                "usage_responses": 0,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": [],
                "protocols": {
                  "unreported": 1
                }
              },
              "jev_usage": {
                "observed_tokens": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "usage_responses": 1,
                "usage_missing_responses": 0,
                "complete": true,
                "complete_sample_ids": [
                  "subscription-read:0"
                ],
                "missing_sample_ids": []
              },
              "estimated_cost": {
                "total": 5.0694e-05,
                "currency": "USD",
                "reason": "estimate under supplied prices; not an actual invoiced fee",
                "assumptions": {
                  "currency": "USD",
                  "cache_hit_input_per_million": 0.003,
                  "cache_miss_input_per_million": 0.15,
                  "output_per_million": 0.6,
                  "jev_input_per_million": 0.042,
                  "jev_output_per_million": 0,
                  "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
                  "checked_at": "2026-10-08T11:55:23.5138153Z",
                  "sources": [
                    "https://api-docs.deepseek.com/quick_start/pricing/",
                    "https://typesafe.ai/",
                    "https://api.typesafe.ai/openapi.json"
                  ]
                },
                "observed_units": {
                  "llm_input_tokens": 0,
                  "llm_output_tokens": 0,
                  "llm_cache_hit_tokens": 0,
                  "llm_cache_miss_tokens": 0,
                  "llm_cache_creation_tokens": 0
                },
                "jev_observed_units": {
                  "jev_input_tokens": 1207,
                  "jev_output_tokens": 187
                },
                "jev_usage_complete": true,
                "jev_pricing_basis": "tokens",
                "jev_requests": 1,
                "llm_estimate": 0.0,
                "jev_estimate": 5.0694e-05
              },
              "llm_attempts_complete": true,
              "turn_attempts": 1,
              "request_latency_all_ms": {
                "count": 1,
                "average": 368.6678,
                "p50": 368.6678,
                "p95": 368.6678
              },
              "request_failure_details": [],
              "fast_status_missing_turn_ids": [],
              "missing_raw_telemetry_ids": []
            }
          }
        }
      },
      "latency_all_tasks_ms": {
        "count": 24,
        "average": 2496.048891666667,
        "p50": 2214.4965,
        "p95": 4073.0813
      },
      "latency_successful_tasks_ms": {
        "count": 24,
        "average": 2496.048891666667,
        "p50": 2214.4965,
        "p95": 4073.0813
      },
      "failure_details": [],
      "stage_usage": {
        "cancel": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 5
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-abort:1",
              "change-cancel:1",
              "recharge-cancel:1",
              "refund-cancel:1",
              "subscribe-cancel:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 5,
          "request_latency_all_ms": {
            "count": 5,
            "average": 52.14268,
            "p50": 48.6007,
            "p95": 67.4495
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 0,
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 14
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "usage_responses": 0,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "cancel-subscription:1",
              "change-missing:2",
              "change-ready:1",
              "recharge-missing:2",
              "recharge-ready:1",
              "recharge-repeat:1",
              "refund-capped:1",
              "refund-composite:1",
              "refund-missing:2",
              "refund-order:1",
              "refund-ready:1",
              "subscribe-flagship:1",
              "subscribe-missing:2",
              "subscribe-ready:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 0,
              "llm_output_tokens": 0,
              "llm_cache_hit_tokens": 0,
              "llm_cache_miss_tokens": 0,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 0,
              "jev_output_tokens": 0
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 0,
            "llm_estimate": 0.0,
            "jev_estimate": 0.0
          },
          "llm_attempts_complete": true,
          "turn_attempts": 14,
          "request_latency_all_ms": {
            "count": 14,
            "average": 73.19271428571429,
            "p50": 68.8875,
            "p95": 112.5164
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "duplicate_confirm": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 290,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 1,
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 1
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "usage_responses": 1,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "recharge-repeat:2"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.00026391,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 2271,
              "llm_output_tokens": 290,
              "llm_cache_hit_tokens": 2048,
              "llm_cache_miss_tokens": 223,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 1198,
              "jev_output_tokens": 186
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 1,
            "llm_estimate": 0.000213594,
            "jev_estimate": 5.0316000000000004e-05
          },
          "llm_attempts_complete": true,
          "turn_attempts": 1,
          "request_latency_all_ms": {
            "count": 1,
            "average": 2118.5854,
            "p50": 2118.5854,
            "p95": 2118.5854
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 63438,
              "llm_output_tokens": 3286,
              "llm_cache_hit_tokens": 57472,
              "llm_cache_miss_tokens": 5966,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 27,
            "usage_responses": 27,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "unreported": 2,
              "openai": 18
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 31920,
              "jev_output_tokens": 4051
            },
            "usage_responses": 35,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "balance-read:0",
              "cancel-abort:0",
              "cancel-subscription:0",
              "cancelled-read:0",
              "change-cancel:0",
              "change-ready:0",
              "recharge-cancel:0",
              "recharge-ready:0",
              "recharge-repeat:0",
              "refund-cancel:0",
              "refund-capped:0",
              "refund-composite:0",
              "refund-order:0",
              "refund-ready:0",
              "satisfied-balance:0",
              "satisfied-subscription:0",
              "subscribe-cancel:0",
              "subscribe-flagship:0",
              "subscribe-ready:0",
              "subscription-read:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.004379556,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 63438,
              "llm_output_tokens": 3286,
              "llm_cache_hit_tokens": 57472,
              "llm_cache_miss_tokens": 5966,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 31920,
              "jev_output_tokens": 4051
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 35,
            "llm_estimate": 0.003038916,
            "jev_estimate": 0.0013406400000000001
          },
          "llm_attempts_complete": true,
          "turn_attempts": 20,
          "request_latency_all_ms": {
            "count": 20,
            "average": 2010.01894,
            "p50": 1768.121,
            "p95": 3617.1256
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "request_missing": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 14255,
              "llm_output_tokens": 860,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1327,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 6,
            "usage_responses": 6,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:0",
              "recharge-missing:0",
              "refund-missing:0",
              "subscribe-missing:0"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.000955812,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 14255,
              "llm_output_tokens": 860,
              "llm_cache_hit_tokens": 12928,
              "llm_cache_miss_tokens": 1327,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 4809,
              "jev_output_tokens": 743
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 4,
            "llm_estimate": 0.000753834,
            "jev_estimate": 0.000201978
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1834.28765,
            "p50": 1373.7085,
            "p95": 2848.5369
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        },
        "supply_slot": {
          "usage": {
            "observed_tokens": {
              "llm_input_tokens": 9909,
              "llm_output_tokens": 235,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1077,
              "llm_cache_creation_tokens": 0
            },
            "observed_llm_attempts": 4,
            "usage_responses": 4,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": [],
            "protocols": {
              "openai": 4
            }
          },
          "jev_usage": {
            "observed_tokens": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "usage_responses": 8,
            "usage_missing_responses": 0,
            "complete": true,
            "complete_sample_ids": [
              "change-missing:1",
              "recharge-missing:1",
              "refund-missing:1",
              "subscribe-missing:1"
            ],
            "missing_sample_ids": []
          },
          "estimated_cost": {
            "total": 0.0006168720000000001,
            "currency": "USD",
            "reason": "estimate under supplied prices; not an actual invoiced fee",
            "assumptions": {
              "currency": "USD",
              "cache_hit_input_per_million": 0.003,
              "cache_miss_input_per_million": 0.15,
              "output_per_million": 0.6,
              "jev_input_per_million": 0.042,
              "jev_output_per_million": 0,
              "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
              "checked_at": "2026-10-08T11:55:23.5138153Z",
              "sources": [
                "https://api-docs.deepseek.com/quick_start/pricing/",
                "https://typesafe.ai/",
                "https://api.typesafe.ai/openapi.json"
              ]
            },
            "observed_units": {
              "llm_input_tokens": 9909,
              "llm_output_tokens": 235,
              "llm_cache_hit_tokens": 8832,
              "llm_cache_miss_tokens": 1077,
              "llm_cache_creation_tokens": 0
            },
            "jev_observed_units": {
              "jev_input_tokens": 6853,
              "jev_output_tokens": 831
            },
            "jev_usage_complete": true,
            "jev_pricing_basis": "tokens",
            "jev_requests": 8,
            "llm_estimate": 0.000329046,
            "jev_estimate": 0.00028782600000000003
          },
          "llm_attempts_complete": true,
          "turn_attempts": 4,
          "request_latency_all_ms": {
            "count": 4,
            "average": 1441.353675,
            "p50": 1358.6495,
            "p95": 1591.8436
          },
          "request_failure_details": [],
          "fast_status_missing_turn_ids": [],
          "missing_raw_telemetry_ids": []
        }
      }
    }
  },
  "paired_latency": {
    "all_three_success": {
      "ids": [
        "balance-read",
        "cancel-abort",
        "cancel-subscription",
        "cancelled-read",
        "change-cancel",
        "change-missing",
        "change-ready",
        "recharge-cancel",
        "recharge-missing",
        "recharge-ready",
        "recharge-repeat",
        "refund-cancel",
        "refund-capped",
        "refund-composite",
        "refund-missing",
        "refund-order",
        "refund-ready",
        "satisfied-balance",
        "satisfied-subscription",
        "subscribe-flagship",
        "subscribe-missing",
        "subscribe-ready",
        "subscription-read"
      ],
      "count": 23,
      "runs": {
        "baseline": {
          "count": 23,
          "average": 1984.2052130434784,
          "p50": 1757.7827,
          "p95": 3662.9065
        },
        "hint": {
          "count": 23,
          "average": 2438.5689173913042,
          "p50": 2106.1397,
          "p95": 4683.8696
        },
        "fast": {
          "count": 23,
          "average": 2438.6753391304346,
          "p50": 2214.4965,
          "p95": 4073.0813
        }
      },
      "baseline_minus_fast_ms": {
        "count": 23,
        "average": -454.4701260869565,
        "p50": -616.5605999999998,
        "p95": 1211.2761
      },
      "hint_minus_fast_ms": {
        "count": 23,
        "average": -0.10642173913038278,
        "p50": -72.13509999999997,
        "p95": 1551.313
      }
    },
    "fast_selected_all_three_success": {
      "ids": [
        "balance-read",
        "subscription-read"
      ],
      "count": 2,
      "runs": {
        "baseline": {
          "count": 2,
          "average": 1711.415,
          "p50": 1665.0473,
          "p95": 1757.7827
        },
        "hint": {
          "count": 2,
          "average": 2028.6455500000002,
          "p50": 2005.0842,
          "p95": 2052.2069
        },
        "fast": {
          "count": 2,
          "average": 439.37925,
          "p50": 424.9873,
          "p95": 453.7712
        }
      },
      "baseline_minus_fast_ms": {
        "count": 2,
        "average": 1272.03575,
        "p50": 1211.2761,
        "p95": 1332.7954
      },
      "hint_minus_fast_ms": {
        "count": 2,
        "average": 1589.2663000000002,
        "p50": 1551.313,
        "p95": 1627.2196000000001
      }
    }
  },
  "fast_selected_task_comparison": {
    "ids": [
      "balance-read",
      "subscription-read"
    ],
    "count": 2,
    "runs": {
      "baseline": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 8982,
            "llm_output_tokens": 222,
            "llm_cache_hit_tokens": 8320,
            "llm_cache_miss_tokens": 662,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 4,
          "usage_responses": 4,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.00025746,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 8982,
            "llm_output_tokens": 222,
            "llm_cache_hit_tokens": 8320,
            "llm_cache_miss_tokens": 662,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 0,
          "llm_estimate": 0.00025746,
          "jev_estimate": 0.0
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 1613.44945,
          "p50": 1568.29,
          "p95": 1658.6089
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "hint": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 9301,
            "llm_output_tokens": 264,
            "llm_cache_hit_tokens": 8448,
            "llm_cache_miss_tokens": 853,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 4,
          "usage_responses": 4,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "usage_responses": 2,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.000413208,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 9301,
            "llm_output_tokens": 264,
            "llm_cache_hit_tokens": 8448,
            "llm_cache_miss_tokens": 853,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 2,
          "llm_estimate": 0.00031169399999999995,
          "jev_estimate": 0.000101514
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 1936.8465999999999,
          "p50": 1907.5653,
          "p95": 1966.1279
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "fast": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 0,
            "llm_output_tokens": 0,
            "llm_cache_hit_tokens": 0,
            "llm_cache_miss_tokens": 0,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 0,
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "unreported": 2
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "usage_responses": 2,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "balance-read:0",
            "subscription-read:0"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.000101514,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 0,
            "llm_output_tokens": 0,
            "llm_cache_hit_tokens": 0,
            "llm_cache_miss_tokens": 0,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 2417,
            "jev_output_tokens": 373
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 2,
          "llm_estimate": 0.0,
          "jev_estimate": 0.000101514
        },
        "llm_attempts_complete": true,
        "turn_attempts": 2,
        "request_latency_all_ms": {
          "count": 2,
          "average": 355.91985,
          "p50": 343.1719,
          "p95": 368.6678
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      }
    },
    "baseline_minus_fast_llm_attempts": 4,
    "baseline_minus_fast_estimated_cost": 0.000155946,
    "baseline_minus_fast_tokens": {
      "llm_input_tokens": 8982,
      "llm_output_tokens": 222
    },
    "hint_minus_fast_llm_attempts": 4,
    "hint_minus_fast_estimated_cost": 0.00031169399999999995,
    "hint_minus_fast_tokens": {
      "llm_input_tokens": 9301,
      "llm_output_tokens": 264
    }
  },
  "non_fast_selected_task_comparison": {
    "ids": [
      "cancel-abort",
      "cancel-subscription",
      "cancelled-read",
      "change-cancel",
      "change-missing",
      "change-ready",
      "recharge-cancel",
      "recharge-missing",
      "recharge-ready",
      "recharge-repeat",
      "refund-cancel",
      "refund-capped",
      "refund-composite",
      "refund-missing",
      "refund-order",
      "refund-ready",
      "satisfied-balance",
      "satisfied-subscription",
      "subscribe-cancel",
      "subscribe-flagship",
      "subscribe-missing",
      "subscribe-ready"
    ],
    "count": 22,
    "runs": {
      "baseline": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 89286,
            "llm_output_tokens": 4533,
            "llm_cache_hit_tokens": 82176,
            "llm_cache_miss_tokens": 7110,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 39,
          "usage_responses": 39,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 18
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "usage_responses": 0,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.004032828,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 89286,
            "llm_output_tokens": 4533,
            "llm_cache_hit_tokens": 82176,
            "llm_cache_miss_tokens": 7110,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 0,
            "jev_output_tokens": 0
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 0,
          "llm_estimate": 0.004032828,
          "jev_estimate": 0.0
        },
        "llm_attempts_complete": true,
        "turn_attempts": 45,
        "request_latency_all_ms": {
          "count": 45,
          "average": 949.1686844444445,
          "p50": 838.8479,
          "p95": 2950.5603
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "hint": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 89454,
            "llm_output_tokens": 4289,
            "llm_cache_hit_tokens": 81024,
            "llm_cache_miss_tokens": 8430,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 38,
          "usage_responses": 38,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 19
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 42369,
            "jev_output_tokens": 5438
          },
          "usage_responses": 46,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.0058604700000000004,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 89454,
            "llm_output_tokens": 4289,
            "llm_cache_hit_tokens": 81024,
            "llm_cache_miss_tokens": 8430,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 42369,
            "jev_output_tokens": 5438
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 46,
          "llm_estimate": 0.004080972,
          "jev_estimate": 0.001779498
        },
        "llm_attempts_complete": true,
        "turn_attempts": 46,
        "request_latency_all_ms": {
          "count": 46,
          "average": 1150.3304847826087,
          "p50": 1225.4853,
          "p95": 2940.1962
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      },
      "fast": {
        "usage": {
          "observed_tokens": {
            "llm_input_tokens": 89873,
            "llm_output_tokens": 4671,
            "llm_cache_hit_tokens": 81280,
            "llm_cache_miss_tokens": 8593,
            "llm_cache_creation_tokens": 0
          },
          "observed_llm_attempts": 38,
          "usage_responses": 38,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": [],
          "protocols": {
            "openai": 27,
            "unreported": 19
          }
        },
        "jev_usage": {
          "observed_tokens": {
            "jev_input_tokens": 42363,
            "jev_output_tokens": 5438
          },
          "usage_responses": 46,
          "usage_missing_responses": 0,
          "complete": true,
          "complete_sample_ids": [
            "cancel-abort:0",
            "cancel-abort:1",
            "cancel-subscription:0",
            "cancel-subscription:1",
            "cancelled-read:0",
            "change-cancel:0",
            "change-cancel:1",
            "change-missing:0",
            "change-missing:1",
            "change-missing:2",
            "change-ready:0",
            "change-ready:1",
            "recharge-cancel:0",
            "recharge-cancel:1",
            "recharge-missing:0",
            "recharge-missing:1",
            "recharge-missing:2",
            "recharge-ready:0",
            "recharge-ready:1",
            "recharge-repeat:0",
            "recharge-repeat:1",
            "recharge-repeat:2",
            "refund-cancel:0",
            "refund-cancel:1",
            "refund-capped:0",
            "refund-capped:1",
            "refund-composite:0",
            "refund-composite:1",
            "refund-missing:0",
            "refund-missing:1",
            "refund-missing:2",
            "refund-order:0",
            "refund-order:1",
            "refund-ready:0",
            "refund-ready:1",
            "satisfied-balance:0",
            "satisfied-subscription:0",
            "subscribe-cancel:0",
            "subscribe-cancel:1",
            "subscribe-flagship:0",
            "subscribe-flagship:1",
            "subscribe-missing:0",
            "subscribe-missing:1",
            "subscribe-missing:2",
            "subscribe-ready:0",
            "subscribe-ready:1"
          ],
          "missing_sample_ids": []
        },
        "estimated_cost": {
          "total": 0.006114636,
          "currency": "USD",
          "reason": "estimate under supplied prices; not an actual invoiced fee",
          "assumptions": {
            "currency": "USD",
            "cache_hit_input_per_million": 0.003,
            "cache_miss_input_per_million": 0.15,
            "output_per_million": 0.6,
            "jev_input_per_million": 0.042,
            "jev_output_per_million": 0,
            "assumption": "Uniform off-peak DeepSeek tariff scenario, JEV published tariff; estimates only, no invoice or per-attempt billing-time attestation",
            "checked_at": "2026-10-08T11:55:23.5138153Z",
            "sources": [
              "https://api-docs.deepseek.com/quick_start/pricing/",
              "https://typesafe.ai/",
              "https://api.typesafe.ai/openapi.json"
            ]
          },
          "observed_units": {
            "llm_input_tokens": 89873,
            "llm_output_tokens": 4671,
            "llm_cache_hit_tokens": 81280,
            "llm_cache_miss_tokens": 8593,
            "llm_cache_creation_tokens": 0
          },
          "jev_observed_units": {
            "jev_input_tokens": 42363,
            "jev_output_tokens": 5438
          },
          "jev_usage_complete": true,
          "jev_pricing_basis": "tokens",
          "jev_requests": 46,
          "llm_estimate": 0.00433539,
          "jev_estimate": 0.0017792460000000002
        },
        "llm_attempts_complete": true,
        "turn_attempts": 46,
        "request_latency_all_ms": {
          "count": 46,
          "average": 1217.2848086956521,
          "p50": 1358.6495,
          "p95": 3575.7527
        },
        "request_failure_details": [],
        "fast_status_missing_turn_ids": [],
        "missing_raw_telemetry_ids": []
      }
    },
    "baseline_minus_fast_llm_attempts": 1,
    "baseline_minus_fast_estimated_cost": -0.002081808,
    "baseline_minus_fast_tokens": {
      "llm_input_tokens": -587,
      "llm_output_tokens": -138
    },
    "hint_minus_fast_llm_attempts": 0,
    "hint_minus_fast_estimated_cost": -0.00025416599999999925,
    "hint_minus_fast_tokens": {
      "llm_input_tokens": -419,
      "llm_output_tokens": -382
    },
    "interpretation": "Differences on tasks without a selected JEV fast path are not attributable to JEV fast-path execution; confirmation/cancellation guards and ordinary model variation must be examined separately."
  },
  "fast_selection_unknown_task_ids": [],
  "matched_quality": {
    "baseline_to_fast": {
      "new_failure_ids": [],
      "recovered_failure_ids": [
        "subscribe-cancel"
      ]
    },
    "hint_to_fast": {
      "new_failure_ids": [],
      "recovered_failure_ids": []
    }
  },
  "limitations": [
    "Original task success, clarification and safety rubric retained without rescoring. Necessary followups are not errors.",
    "Redundant clarification is a heuristic candidate for manual review, not a proven error.",
    "Task duration includes final state verification but excludes fixture setup; synthetic followups have no user think time.",
    "All turn attempts, including failed responses and selected tool errors, remain in usage and cost denominators.",
    "Raw body telemetry is authoritative; missing or malformed raw telemetry stays unavailable, not zero.",
    "Same-task subsets may contain different turn sequences; they measure complete tasks, not a fabricated one-to-one turn match.",
    "Selected-task savings include the whole task and do not independently isolate a causal JEV effect.",
    "Independent fixture tenant IDs are checked across every task and arm; setup failures lacking an ID remain explicit.",
    "Repeated runs remain subject to upstream load and model variability."
  ],
  "sources": {
    "baseline": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\tasks-nojev\\tasks.json",
      "sha256": "2c14e7194cdd75c7bf3eb619333775ed405938434fb4abb3f8c7d7d70b7b0455"
    },
    "hint": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\tasks-hint\\tasks.json",
      "sha256": "6055d5e3ce9be131d73c2263975e21a74d4c35cd27fc5e0eaa22e3ead00d0dd5"
    },
    "fast": {
      "path": "E:\\github项目\\ai-gateway\\eval\\reports\\jev-fast-20261008-1791460424883\\tasks-fast\\tasks.json",
      "sha256": "bb20e968e9bcdb4a5c4db1426c8df53c7b9bbfaf5d5401cb7cfb54ce309d984f"
    }
  }
}
```
